USE [tempdb]
GO

SET NOCOUNT ON

/* SET UP TABLES */
CREATE TABLE dbo.tb_source (
    s_pk int IDENTITY(1,1) NOT NULL,
    s_desc varchar(50) NOT NULL )
GO

CREATE TABLE dbo.tb_source_audit (
    d_pk int IDENTITY(1,1) NOT NULL,
    d_action smallint NOT NULL,
    d_spk int NOT NULL,
    d_sdesc varchar(50) NOT NULL )
GO

/* SET UP AUDIT TRIGGER */
CREATE TRIGGER trg_auditsource 
ON tb_source 
AFTER INSERT, UPDATE, DELETE
AS
SET NOCOUNT ON
DECLARE @insert_action smallint,
        @update_action smallint,
        @delete_action smallint
BEGIN
    SELECT  @insert_action = 1,
            @update_action = 2,
            @delete_action = 3

    -- check for updates
    IF EXISTS(SELECT * FROM DELETED)
    BEGIN
        -- filter deletes only
        INSERT INTO dbo.tb_source_audit (d_action, d_spk, d_sdesc)
            SELECT @delete_action, s_pk, s_desc 
            FROM DELETED
            WHERE s_pk NOT IN (SELECT s_pk FROM INSERTED)

        -- filter updates
        INSERT INTO dbo.tb_source_audit (d_action, d_spk, d_sdesc)
            SELECT @update_action, s_pk, s_desc 
            FROM INSERTED
            WHERE s_pk IN (SELECT s_pk FROM DELETED)
    END
    ELSE 
    -- inserts only
    BEGIN
        INSERT INTO dbo.tb_source_audit (d_action, d_spk, d_sdesc)
            SELECT @insert_action, s_pk, s_desc 
            FROM INSERTED
    END
END
GO


/* TESTING */
/*
SELECT * FROM dbo.tb_source
SELECT * FROM dbo.tb_source_audit
*/

INSERT INTO dbo.tb_source VALUES ('item 1')
-- 1 record inserted in source table
-- 1 record inserted in audit table

INSERT INTO dbo.tb_source 
    SELECT 'item 2' UNION ALL
    SELECT 'item 3' UNION ALL
    SELECT 'item 4' UNION ALL
    SELECT 'item 5' UNION ALL
    SELECT 'item 6'
-- 5 records inserted in source table
-- 5 records inserted in audit table

UPDATE dbo.tb_source SET s_desc = 'modified item 5' WHERE s_desc = 'item 5'
-- 1 record updated in source table
-- 1 record updated in audit table

DELETE FROM dbo.tb_source WHERE s_pk = 4
-- 1 record deleted from source table
-- 1 record deleted from audit table

UPDATE dbo.tb_source SET s_desc = 'same desc' WHERE s_pk IN (2,3)
-- 2 records updated in source table
-- 2 records updated in audit table

DELETE FROM dbo.tb_source WHERE s_pk IN (1, 6)
-- 2 records deleted from source table
-- 2 records deleted from audit table


/* CLEAN UP */
DROP TABLE dbo.tb_source;
DROP TABLE dbo.tb_source_audit;
GO
