-- DROP TABLE [SQLMONITOR].[tb_indexusagestats]
-- DROP SCHEMA [SQLMONITOR]

CREATE SCHEMA [SQLMONITOR];
GO


-- storage
CREATE TABLE [SQLMONITOR].[tb_indexusagestats] (
    [ius_DatabaseID] smallint NOT NULL
    ,[ius_DatabaseName] nvarchar(128) NOT NULL
    ,[ius_ObjectID] int NOT NULL
    ,[ius_ObjectName] nvarchar(128) NOT NULL
    ,[ius_IndexID] int NOT NULL
    ,[ius_IndexName] nvarchar(128) NULL
    ,[ius_IndexType] nvarchar(60) NOT NULL
    ,[ius_UserSeeks] bigint NOT NULL DEFAULT (0)
    ,[ius_UserScans] bigint NOT NULL DEFAULT (0)
    ,[ius_UserBookmarkLookups] bigint NOT NULL DEFAULT (0)
    ,[ius_UserUpdates] bigint NULL DEFAULT (0)
    ,[ius_LastUserSeek] datetime NULL
    ,[ius_LastUserScan] datetime NULL
    ,[ius_LastUserBookmarkLookup] datetime NULL
    ,[ius_LastUserUpdate] datetime NULL
    ,[ius_LastPollUserSeeks] bigint NOT NULL DEFAULT (0)
    ,[ius_LastPollUserScans] bigint NOT NULL DEFAULT (0)
    ,[ius_LastPollUserBookmarkLookups] bigint NOT NULL DEFAULT (0)
    ,[ius_LastPollUserUpdates] bigint NULL DEFAULT (0)
    ,[ius_LastPollDate] datetime NOT NULL DEFAULT (CURRENT_TIMESTAMP)
    ,[ius_DateCreated] datetime NOT NULL DEFAULT (CURRENT_TIMESTAMP)
    ,[ius_DateDeleted] datetime NULL
)
GO


CREATE PROCEDURE [SQLMONITOR].usp_persist_index_usage_stats
    @databasename nvarchar(128)
AS 
SET NOCOUNT ON

IF NOT EXISTS (SELECT [name] FROM sys.databases WHERE [name] = @databasename)
BEGIN
    RAISERROR('Could not locate entry in sysdatabases for database ''%s''. No entry found with that name. Make sure that the name is entered correctly.', 16, 1, @databasename);
    RETURN -1
END

DECLARE @cmd nvarchar(4000);
DECLARE @last_service_start_date datetime;
DECLARE @last_data_persist_date datetime;

-- Update index id's for situatuons where a table was dropped and recreated with the same name and indexes 
-- since the last polling time but SQL Server assigned a different object_id
SET @cmd = 'UPDATE ius
    SET ius.[ius_ObjectID] = i.[object_id], ius.[ius_IndexID] = i.[index_id], ius.[ius_DateDeleted] = NULL
FROM [' + @databasename + '].sys.indexes i 
    INNER JOIN [' + @databasename + '].sys.objects o ON o.[object_id] = i.[object_id]
    INNER JOIN [SQLMONITOR].[tb_indexusagestats] ius ON (ius.[ius_ObjectName] = o.[name] 
        AND ISNULL(ius.[ius_IndexName], ius.[ius_ObjectName]) = ISNULL(i.[name], o.[name]))
        AND ius.[ius_ObjectID] != i.[object_id]
WHERE ius.[ius_DatabaseID] = DB_ID(''' + @databasename + ''')
AND i.[object_id] > 100 AND o.[type] = ''U'';';

EXEC sp_executesql @cmd;


-- Insert indexes created since the last polling date/time
SET @cmd = 'SELECT 
    DB_ID(''' + @databasename + ''')
    ,N''' + @databasename + '''
    ,i.[object_id]
    ,o.[name]
    ,i.[index_id]
    ,i.[name]
    ,i.[type_desc]
    ,0, 0, 0, 0
    ,NULL,NULL,NULL,NULL
    ,0, 0, 0, 0
    ,(SELECT [create_date]-1 FROM sys.databases WHERE [name] = ''tempdb'') -- set the initial date to one day before the tempdb was created
    ,CURRENT_TIMESTAMP,NULL
FROM [' + @databasename + '].sys.indexes i 
    INNER JOIN [' + @databasename + '].sys.objects o ON o.[object_id] = i.[object_id]
    LEFT OUTER JOIN [SQLMONITOR].[tb_indexusagestats] ius ON ius.[ius_ObjectID] = i.[object_id] 
        AND ius.[ius_IndexID] = i.[index_id]
WHERE i.[object_id] > 100 AND o.[type] = ''U''
AND ius.[ius_ObjectID] IS NULL AND ius.[ius_IndexID] IS NULL
ORDER BY i.[object_id], i.[index_id];';

INSERT INTO [SQLMONITOR].[tb_indexusagestats] (
    [ius_DatabaseID],[ius_DatabaseName],[ius_ObjectID],[ius_ObjectName],[ius_IndexID],[ius_IndexName],[ius_IndexType] 
    ,[ius_UserSeeks],[ius_UserScans],[ius_UserBookmarkLookups],[ius_UserUpdates]
    ,[ius_LastUserSeek],[ius_LastUserScan],[ius_LastUserBookmarkLookup],[ius_LastUserUpdate]
    ,[ius_LastPollUserSeeks],[ius_LastPollUserScans],[ius_LastPollUserBookmarkLookups],[ius_LastPollUserUpdates]
    ,[ius_LastPollDate]
    ,[ius_DateCreated],[ius_DateDeleted]
    )
EXEC sp_executesql @cmd;


-- Handle indexes deleted since the last polling time
SET @cmd = 'UPDATE ius
SET ius.[ius_DateDeleted] = CURRENT_TIMESTAMP
FROM [' + @databasename + '].sys.indexes i 
    INNER JOIN [' + @databasename + '].sys.objects o ON o.[object_id] = i.[object_id]
    RIGHT JOIN [SQLMONITOR].[tb_indexusagestats] ius ON (ius.[ius_ObjectName] = o.[name] 
        AND ISNULL(ius.[ius_IndexName], ius.[ius_ObjectName]) = ISNULL(i.[name], o.[name]))
        AND ius.[ius_ObjectID] = i.[object_id]
WHERE ius.[ius_DatabaseID] = DB_ID(''' + @databasename + ''')
AND i.[object_id] IS NULL;';

EXEC sp_executesql @cmd;


-- Determine last service restart date based upon tempdb creation date
SELECT @last_service_start_date = [create_date] FROM sys.databases WHERE [name] = 'tempdb';
  
-- Return the value for the last refresh date of the persisting table
SELECT @last_data_persist_date = MAX([ius_LastPollDate]) FROM [SQLMONITOR].[tb_indexusagestats];

-- Handle updated records
IF (@last_service_start_date < @last_data_persist_date)
BEGIN
    -- Service NOT restarted since the last poll date
    UPDATE MDDIUS
    SET MDDIUS.[ius_UserSeeks] = MDDIUS.[ius_UserSeeks]+(SDDIUS.[user_seeks] - MDDIUS.[ius_LastPollUserSeeks]),
        MDDIUS.[ius_UserScans] = MDDIUS.[ius_UserScans]+(SDDIUS.[user_scans] - MDDIUS.[ius_LastPollUserScans]),
        MDDIUS.[ius_UserBookmarkLookups] = MDDIUS.[ius_UserBookmarkLookups]+(SDDIUS.[user_lookups] - MDDIUS.[ius_LastPollUserBookmarkLookups]),
        MDDIUS.[ius_UserUpdates] = MDDIUS.[ius_UserUpdates]+(SDDIUS.[user_updates] - MDDIUS.[ius_LastPollUserUpdates]),
        MDDIUS.[ius_LastUserSeek] = SDDIUS.[last_user_seek],
        MDDIUS.[ius_LastUserScan] = SDDIUS.[last_user_scan],
        MDDIUS.[ius_LastUserBookmarkLookup] = SDDIUS.[last_user_lookup],
        MDDIUS.[ius_LastUserUpdate] = SDDIUS.[last_user_update],
        MDDIUS.[ius_LastPollUserSeeks] = SDDIUS.[user_seeks],
        MDDIUS.[ius_LastPollUserScans] = SDDIUS.[user_scans],
        MDDIUS.[ius_LastPollUserBookmarkLookups] = SDDIUS.[user_lookups],
        MDDIUS.[ius_LastPollUserUpdates] = SDDIUS.[user_updates],
        MDDIUS.[ius_LastPollDate] = CURRENT_TIMESTAMP,
        MDDIUS.[ius_DateDeleted] = NULL -- NULL-ified to cater for indexes which were dropped and recreated
    FROM [sys].[dm_db_index_usage_stats] SDDIUS 
        INNER JOIN [SQLMONITOR].[tb_indexusagestats] MDDIUS ON SDDIUS.[database_id] = MDDIUS.[ius_DatabaseID]
            AND SDDIUS.[object_id] = MDDIUS.[ius_ObjectID] AND SDDIUS.[index_id] = MDDIUS.[ius_IndexID]
    WHERE SDDIUS.[database_id] = DB_ID(@databasename)
END
ELSE
BEGIN
    -- Service restarted since the last poll date
    UPDATE MDDIUS
    SET MDDIUS.[ius_UserSeeks] = MDDIUS.[ius_UserSeeks]+ SDDIUS.[user_seeks],
        MDDIUS.[ius_UserScans] = MDDIUS.[ius_UserScans]+ SDDIUS.[user_scans],
        MDDIUS.[ius_UserBookmarkLookups] = MDDIUS.[ius_UserBookmarkLookups]+ SDDIUS.[user_lookups],
        MDDIUS.[ius_UserUpdates] = MDDIUS.[ius_UserUpdates]+ SDDIUS.[user_updates],
        MDDIUS.[ius_LastUserSeek] = SDDIUS.[last_user_seek],
        MDDIUS.[ius_LastUserScan] = SDDIUS.[last_user_scan],
        MDDIUS.[ius_LastUserBookmarkLookup] = SDDIUS.[last_user_lookup],
        MDDIUS.[ius_LastUserUpdate] = SDDIUS.[last_user_update],
        MDDIUS.[ius_LastPollUserSeeks] = SDDIUS.[user_seeks],
        MDDIUS.[ius_LastPollUserScans] = SDDIUS.[user_scans],
        MDDIUS.[ius_LastPollUserBookmarkLookups] = SDDIUS.[user_lookups],
        MDDIUS.[ius_LastPollUserUpdates] = SDDIUS.[user_updates],
        MDDIUS.[ius_LastPollDate] = CURRENT_TIMESTAMP,
        MDDIUS.[ius_DateDeleted] = NULL -- NULL-ified to cater for indexes which were dropped and recreated
    FROM [sys].[dm_db_index_usage_stats] SDDIUS 
        INNER JOIN [SQLMONITOR].[tb_indexusagestats] MDDIUS ON SDDIUS.[database_id] = MDDIUS.[ius_DatabaseID]
            AND SDDIUS.[object_id] = MDDIUS.[ius_ObjectID] AND SDDIUS.[index_id] = MDDIUS.[ius_IndexID]
    WHERE SDDIUS.[database_id] = DB_ID(@databasename)
END

GO
