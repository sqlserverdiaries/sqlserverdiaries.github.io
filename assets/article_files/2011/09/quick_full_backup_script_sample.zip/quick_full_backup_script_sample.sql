USE [master]
GO

SET NOCOUNT ON;

DECLARE @databasename nvarchar(128),    -- database name
        @destfolder nvarchar(256),      -- destination folder to store the backup file
        @fileName nvarchar(256),        -- backup file filename
        @fileDate nvarchar(20),         -- date formatted and used for file name
        @fileTime nvarchar(20),         -- time formatted and used for file name
        @backupsetdescription nvarchar(256); -- backup set identifier

SET @databasename = N'AdventureWorks';
SET @destfolder = N'D:\TEMP\'; --'
SET @backupsetdescription = N'AD-Hoc Database Backup';

-- set date and description
SET @fileDate = CONVERT(VARCHAR(20),CURRENT_TIMESTAMP,112);
SET @backupsetdescription = @backupsetdescription + ' ' + CONVERT(VARCHAR(20),CURRENT_TIMESTAMP,120);

-- set time
SET @fileTime = CONVERT(VARCHAR(20),CURRENT_TIMESTAMP,108);
SET @fileTime = REPLACE(@fileTime, ':', '');

-- backup!
SET @fileName = @destfolder + @databasename + '_' + @fileDate + @fileTime + '.BAK';
BACKUP DATABASE @databasename 
TO DISK = @fileName 
WITH 
    NAME = @backupsetdescription, 
    INIT, STATS = 25, COPY_ONLY;
GO
