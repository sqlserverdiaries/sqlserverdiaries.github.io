-- DROP TABLE [SQLMONITOR].[tb_missingindexstats]
-- DROP SCHEMA [SQLMONITOR]

CREATE SCHEMA [SQLMONITOR];
GO


-- storage
CREATE TABLE [SQLMONITOR].[tb_missingindexstats] (
    [mis_DatabaseID] smallint NOT NULL
    ,[mis_DatabaseName] nvarchar(128) NOT NULL
    ,[mis_ObjectID] int NOT NULL
    ,[mis_ObjectName] nvarchar(128) NOT NULL
    ,[mis_EqualityColumns] nvarchar(4000) NULL
    ,[mis_InEqualityColumns] nvarchar(4000) NULL
    ,[mis_IncludedColumns] nvarchar(4000) NULL
    ,[mis_UniqueCompiles] bigint NOT NULL DEFAULT (0)
    ,[mis_UserSeeks] bigint NOT NULL DEFAULT (0)
    ,[mis_UserScans] bigint NOT NULL DEFAULT (0)
    ,[mis_LastUserSeek] datetime NULL
    ,[mis_LastUserScan] datetime NULL
    ,[mis_AvgTotalUserCost] float NOT NULL
    ,[mis_AvgUserImpact] float NOT NULL
    ,[mis_LastPollUniqueCompiles] bigint NOT NULL DEFAULT (0)
    ,[mis_LastPollUserSeeks] bigint NOT NULL DEFAULT (0)
    ,[mis_LastPollUserScans] bigint NOT NULL DEFAULT (0)
    ,[mis_LastPollDate] datetime NOT NULL DEFAULT (CURRENT_TIMESTAMP)
    ,[mis_DateCreated] datetime NOT NULL DEFAULT (CURRENT_TIMESTAMP)
    ,[mis_RecordChecksum] int NOT NULL
);
GO


-- TRUNCATE TABLE [SQLMONITOR].[tb_missingindexstats]
-- initial data set
DECLARE @databasename nvarchar(128);
DECLARE @cmd nvarchar(4000);
SET @databasename = N'marvalsql'
SET @cmd = '
SELECT d.[database_id]
    ,''' + @databasename + '''
    ,d.[object_id]
    ,OBJECT_NAME(d.[object_id], d.[database_id])
    ,d.[equality_columns]
    ,d.[inequality_columns]
    ,d.[included_columns]
    ,s.[unique_compiles]
    ,s.[user_seeks]
    ,s.[user_scans]
    ,s.[last_user_seek]
    ,s.[last_user_scan]
    ,s.[avg_total_user_cost]
    ,s.[avg_user_impact]
    ,0
    ,0
    ,0
    ,(SELECT [create_date]-1 FROM sys.databases WHERE [name] = ''tempdb'') -- set the initial date to one day before the tempdb was created
    ,CURRENT_TIMESTAMP
    ,CHECKSUM(OBJECT_NAME(d.[object_id], d.[database_id])
        ,d.[equality_columns]
        ,d.[inequality_columns]
        ,d.[included_columns]
        )
FROM sys.dm_db_missing_index_groups g
    INNER JOIN sys.dm_db_missing_index_details d ON d.index_handle = g.index_handle
    INNER JOIN sys.dm_db_missing_index_group_stats s ON s.group_handle = g.index_group_handle
WHERE database_id = DB_ID(''' + @databasename + ''');';
-- PRINT @cmd;

EXEC sp_executesql @cmd;

INSERT INTO [SQLMONITOR].[tb_missingindexstats] (
    [mis_DatabaseID],[mis_DatabaseName],[mis_ObjectID],[mis_ObjectName],[mis_EqualityColumns],[mis_InEqualityColumns],[mis_IncludedColumns],
    [mis_UniqueCompiles],[mis_UserSeeks],[mis_UserScans],[mis_LastUserSeek],[mis_LastUserScan],[mis_AvgTotalUserCost],[mis_AvgUserImpact],
    [mis_LastPollUniqueCompiles],[mis_LastPollUserSeeks],[mis_LastPollUserScans],[mis_LastPollDate],[mis_DateCreated],[mis_RecordChecksum]
    )
EXEC sp_executesql @cmd;


-- check initial data set
SELECT * FROM [SQLMONITOR].[tb_missingindexstats];





CREATE PROCEDURE [SQLMONITOR].usp_persist_missing_index_stats
    @databasename nvarchar(128)
AS 
SET NOCOUNT ON

IF NOT EXISTS (SELECT [name] FROM sys.databases WHERE [name] = @databasename)
BEGIN
    RAISERROR('Could not locate entry in sysdatabases for database ''%s''. No entry found with that name. Make sure that the name is entered correctly.', 16, 1, @databasename);
    RETURN -1
END

DECLARE @cmd nvarchar(4000);
DECLARE @last_service_start_date datetime;
DECLARE @last_data_persist_date datetime;

-- Update object id's for situatuons where a table was dropped and recreated with the same name
-- since the last polling time but SQL Server assigned a different object_id
SET @cmd = 'UPDATE ius
    SET ius.[mis_ObjectID] = o.[object_id]
FROM [' + @databasename + '].sys.objects o
    INNER JOIN [SQLMONITOR].[tb_missingindexstats] ius ON ius.[mis_ObjectName] = o.[name] AND ius.[mis_ObjectID] != o.[object_id]
WHERE ius.[mis_DatabaseID] = DB_ID(''' + @databasename + ''')
AND o.[type] = ''U'';';

EXEC sp_executesql @cmd;


-- Insert missing indexes created since the last polling date/time
SET @cmd = '
SELECT d.[database_id]
    ,''' + @databasename + '''
    ,d.[object_id]
    ,OBJECT_NAME(d.[object_id], d.[database_id])
    ,d.[equality_columns]
    ,d.[inequality_columns]
    ,d.[included_columns]
    ,s.[unique_compiles]
    ,s.[user_seeks]
    ,s.[user_scans]
    ,s.[last_user_seek]
    ,s.[last_user_scan]
    ,s.[avg_total_user_cost]
    ,s.[avg_user_impact]
    ,s.[unique_compiles]
    ,s.[user_seeks]
    ,s.[user_scans]
    ,CURRENT_TIMESTAMP
    ,CURRENT_TIMESTAMP
    ,CHECKSUM(OBJECT_NAME(d.[object_id], d.[database_id])
        ,d.[equality_columns]
        ,d.[inequality_columns]
        ,d.[included_columns]
        )
FROM sys.dm_db_missing_index_groups g
    INNER JOIN sys.dm_db_missing_index_details d ON d.index_handle = g.index_handle
    INNER JOIN sys.dm_db_missing_index_group_stats s ON s.group_handle = g.index_group_handle
    LEFT OUTER JOIN [SQLMONITOR].[tb_missingindexstats] ius ON [mis_RecordChecksum] = 
        CHECKSUM(OBJECT_NAME(d.[object_id], d.[database_id])
            ,d.[equality_columns]
            ,d.[inequality_columns]
            ,d.[included_columns]
        )
WHERE d.database_id = DB_ID(''' + @databasename + ''')
AND ius.[mis_DatabaseID] IS NULL;';

INSERT INTO [SQLMONITOR].[tb_missingindexstats] (
    [mis_DatabaseID],[mis_DatabaseName],[mis_ObjectID],[mis_ObjectName],[mis_EqualityColumns],[mis_InEqualityColumns],[mis_IncludedColumns],
    [mis_UniqueCompiles],[mis_UserSeeks],[mis_UserScans],[mis_LastUserSeek],[mis_LastUserScan],[mis_AvgTotalUserCost],[mis_AvgUserImpact],
    [mis_LastPollUniqueCompiles],[mis_LastPollUserSeeks],[mis_LastPollUserScans],[mis_LastPollDate],[mis_DateCreated],[mis_RecordChecksum]
    )
EXEC sp_executesql @cmd;


-- Determine last service restart date based upon tempdb creation date
SELECT @last_service_start_date = [create_date] FROM sys.databases WHERE [name] = 'tempdb';
  
-- Return the value for the last refresh date of the persisting table
SELECT @last_data_persist_date = MAX([mis_LastPollDate]) FROM [SQLMONITOR].[tb_missingindexstats];

-- Handle updated records
IF (@last_service_start_date < @last_data_persist_date)
BEGIN
    -- Service NOT restarted since the last poll date
    UPDATE MDDIUS
    SET MDDIUS.[mis_UniqueCompiles] = MDDIUS.[mis_UniqueCompiles] + (s.[unique_compiles] - MDDIUS.[mis_LastPollUniqueCompiles]),
        MDDIUS.[mis_UserSeeks] = MDDIUS.[mis_UserSeeks] + (s.[user_seeks] - MDDIUS.[mis_LastPollUserSeeks]),
        MDDIUS.[mis_UserScans] = MDDIUS.[mis_UserScans] + (s.[user_scans] - MDDIUS.[mis_LastPollUserScans]),
        MDDIUS.[mis_LastUserSeek] = s.[last_user_seek],
        MDDIUS.[mis_LastUserScan] = s.[last_user_scan],
        MDDIUS.[mis_LastPollUniqueCompiles] = s.[unique_compiles],
        MDDIUS.[mis_LastPollUserSeeks] = s.[user_seeks],
        MDDIUS.[mis_LastPollUserScans] = s.[user_scans],
        MDDIUS.[mis_LastPollDate] = CURRENT_TIMESTAMP
    FROM sys.dm_db_missing_index_groups g
        INNER JOIN sys.dm_db_missing_index_details d ON d.index_handle = g.index_handle
        INNER JOIN sys.dm_db_missing_index_group_stats s ON s.group_handle = g.index_group_handle
        INNER JOIN [SQLMONITOR].[tb_missingindexstats] MDDIUS ON d.[database_id] = MDDIUS.[mis_DatabaseID]
            AND CHECKSUM(OBJECT_NAME(d.[object_id], d.[database_id])
                    ,d.[equality_columns]
                    ,d.[inequality_columns]
                    ,d.[included_columns]
                ) = MDDIUS.[mis_RecordChecksum]
    WHERE d.[database_id] = DB_ID(@databasename)
END
ELSE
BEGIN
    -- Service restarted since the last poll date
    UPDATE MDDIUS
    SET MDDIUS.[mis_UniqueCompiles] = MDDIUS.[mis_UniqueCompiles] + s.[unique_compiles],
        MDDIUS.[mis_UserSeeks] = MDDIUS.[mis_UserSeeks] + s.[user_seeks],
        MDDIUS.[mis_UserScans] = MDDIUS.[mis_UserScans] + s.[user_scans],
        MDDIUS.[mis_LastUserSeek] = s.[last_user_seek],
        MDDIUS.[mis_LastUserScan] = s.[last_user_scan],
        MDDIUS.[mis_LastPollUniqueCompiles] = s.[unique_compiles],
        MDDIUS.[mis_LastPollUserSeeks] = s.[user_seeks],
        MDDIUS.[mis_LastPollUserScans] = s.[user_scans],
        MDDIUS.[mis_LastPollDate] = CURRENT_TIMESTAMP
    FROM sys.dm_db_missing_index_groups g
        INNER JOIN sys.dm_db_missing_index_details d ON d.index_handle = g.index_handle
        INNER JOIN sys.dm_db_missing_index_group_stats s ON s.group_handle = g.index_group_handle
        INNER JOIN [SQLMONITOR].[tb_missingindexstats] MDDIUS ON d.[database_id] = MDDIUS.[mis_DatabaseID]
            AND CHECKSUM(OBJECT_NAME(d.[object_id], d.[database_id])
                    ,d.[equality_columns]
                    ,d.[inequality_columns]
                    ,d.[included_columns]
                ) = MDDIUS.[mis_RecordChecksum]
    WHERE d.[database_id] = DB_ID(@databasename)
END

GO
