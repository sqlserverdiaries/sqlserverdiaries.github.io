
EXEC sp_configure 'show advanced options', 1; -- To allow advanced options to be changed
RECONFIGURE; -- Update the currently configured value for advanced options
GO
EXEC sp_configure 'xp_cmdshell', 1; -- Enable the feature
RECONFIGURE -- Update the currently configured value for this feature
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[lp_load_files]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[lp_load_files]
GO

CREATE PROCEDURE dbo.lp_load_files (
    @databasename   nvarchar(128),      -- database to load to
    @schemaname     nvarchar(128),      -- schema name
    @tablename      nvarchar(128),      -- table name to where the data will be loaded
    @sourcefolder   nvarchar(128),      -- folder to search for files
    @fielddelimiter nvarchar(5) = '|',  -- column delimiter with default set (see SQL Server BOL for details)
    @rowdelimiter nvarchar(5) = '\n',   -- row delimiter with default set (see SQL Server BOL for details)
    @rowcount       int = 0,            -- number of rows to load - for ALL set to 0
    @debug          bit = 0             -- 1: prints messages; 0: does not
    )
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @filesinfolder TABLE (
        [filepk] int identity(1, 1), 
        [filename] nvarchar(128));

    DECLARE @fullobjectname nvarchar(384);
    DECLARE @cmdstring nvarchar(128);   -- 'ms-dos' command to execute
    DECLARE @filename nvarchar(128);    -- file name variable
    DECLARE @sqlcmd nvarchar(500);
    DECLARE @MAXROWS nvarchar(5);

    -- verify that destination object exists
    SET @fullobjectname = QUOTENAME(@databasename,'[') + '.' + QUOTENAME(@schemaname,'[') + '.' + QUOTENAME(@tablename,'[');
    IF NOT EXISTS(
        SELECT 1 FROM INFORMATION_SCHEMA.TABLES 
        WHERE TABLE_CATALOG = @databasename
        AND TABLE_SCHEMA = @schemaname AND TABLE_NAME = @tablename
        -- NOTE: Not filtering for TABLE_TYPE='BASE TABLE' since data might be loaded into a VIEW
        )
    BEGIN
        RAISERROR('Object ''%s'' does not exist!', 16, 1, @fullobjectname);
        RETURN;
    END

    SET @MAXROWS = CONVERT(nvarchar(5), @rowcount);

    -- execute 'DIR' command to list files...
    --   /B     : in bare format
    --   /A-D   : do not show folders
    --   /OD    : order by date
    --   /TC    : use creation time for sorting
    SET @cmdstring = 'DIR /B /A-D /OD /TC ' + @sourcefolder;
    INSERT INTO @filesinfolder
        EXEC xp_cmdshell @cmdstring;

    DECLARE curData CURSOR FOR 
        SELECT @sourcefolder + [filename] FROM @filesinfolder 
        WHERE [filename] IS NOT NULL ORDER BY [filepk] ASC

    OPEN curData
    FETCH NEXT FROM curData INTO @filename
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        IF @debug = 1 PRINT 'LOADING: ' + @filename + ' to ' + @fullobjectname;

        SET @sqlcmd = N'
BULK INSERT ' + @fullobjectname + ' 
FROM ''' + @filename + '''
WITH ( 
   FIELDTERMINATOR = ''' + @fielddelimiter + ''', 
   FIRSTROW = 0, 
   KEEPNULLS, 
   LASTROW = ' + @MAXROWS + ', 
   MAXERRORS = 1, 
   ROWTERMINATOR = ''' + @rowdelimiter + ''')';

        EXECUTE sp_executesql @sqlcmd;

        FETCH NEXT FROM curData INTO @filename
    END
    CLOSE curData
    DEALLOCATE curData;

    RETURN
END
GO
