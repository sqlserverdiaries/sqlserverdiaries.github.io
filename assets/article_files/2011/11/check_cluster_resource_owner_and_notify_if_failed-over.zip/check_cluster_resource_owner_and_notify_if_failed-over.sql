SET NOCOUNT ON;

DECLARE @HostName nvarchar(128);
DECLARE @PrimaryNode nvarchar(128);

SET @HostName = CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS nvarchar(128));
SET @PrimaryNode = 'SQLNODE1'; /* ***** CHANGE THIS ***** */
IF (@HostName <> @PrimaryNode)
BEGIN
    DECLARE @InstanceName nvarchar(128);
    DECLARE @DBMailProfileName nvarchar(128);
    DECLARE @EmailRecipients nvarchar(128);
    DECLARE @EmailCCRecipients nvarchar(128);
    DECLARE @EmailSubject nvarchar(255);
    DECLARE @EmailBody nvarchar(MAX);
    DECLARE @DBAEmail nvarchar(128);
    DECLARE @SQLErrorLogPath nvarchar(256);

    -- get the path of the SQL Server Error Log
    CREATE TABLE #SQLErrorLogPath(
        LogDate datetime,
        ProcessInfo nvarchar(128),
        LogText nvarchar(MAX)
    );
    INSERT INTO #SQLErrorLogPath EXEC sp_readerrorlog 0, 1, 'Logging SQL Server messages in file';
    SET @SQLErrorLogPath = (SELECT REPLACE(LogText, 'Logging SQL Server messages in file', '') FROM #SQLErrorLogPath)
    SET @SQLErrorLogPath = REPLACE(LEFT(LTRIM(@SQLErrorLogPath), LEN(LTRIM(@SQLErrorLogPath))-1), '''', '');

    -- retrieve the SQL Server instance name (no hard-coding!)
    SET @InstanceName = 
        UPPER(ISNULL(@@SERVERNAME, CAST(SERVERPROPERTY('ServerName') AS nvarchar(128))));
    SET @DBMailProfileName = 'SQL Server Email Notifications - ' + @InstanceName;

    SET @EmailRecipients = '247support@mycompany.com'; /* ***** REPLACE AS NECESSARY ***** */
    SET @EmailCCRecipients = 'dbateam@mycompany.com'; /* ***** REPLACE AS NECESSARY ***** */
    SET @DBAEmail = 'dbateam@mycompany.com'; /* ***** REPLACE AS NECESSARY ***** */
    SET @EmailSubject = 'SQL Server Cluster Resource ' + @InstanceName + ' Failed-Over';
    SET @EmailBody = 'Dear recipient,

Kindly note that the SQL Server cluster resource ' + @InstanceName + ' is in a failed-over state.

Please take a copy of and review the following error logs, and action accordingly:

 - SQL Server Error Log (' + @SQLErrorLogPath + ')
 - Windows Event Viewer
 - Cluster Log (C:\WINDOWS\CLUSTER\Cluster.log)

Thank you.

DBA Team
My Company Name
 
Email: ' + @DBAEmail + '
URL: http://www.mycompany.com
';

    EXEC msdb.dbo.sp_send_dbmail
        @profile_name = @DBMailProfileName,
        @recipients = @EmailRecipients,
        @copy_recipients = @EmailCCRecipients,
        @subject = @EmailSubject,
        @body = @EmailBody,
        @body_format = 'TEXT';

    DROP TABLE #SQLErrorLogPath;
END;
