SET NOCOUNT ON;

DECLARE @HostName nvarchar(128);
DECLARE @PrimaryNode nvarchar(128);

-- get computer name
CREATE TABLE #cmdshell (s_output varchar(8000));
INSERT INTO #cmdshell EXEC xp_cmdshell 'net config server';
SET @HostName = (
    SELECT REPLACE(LTRIM(REPLACE(s_output,'Server Name','')),'\\','')
    FROM #cmdshell WHERE s_output LIKE 'Server Name%')
DROP TABLE #cmdshell;

SET @PrimaryNode = 'SQLNODE1'; /* ***** CHANGE THIS ***** */
IF (@HostName <> @PrimaryNode)
BEGIN
    DECLARE @InstanceName nvarchar(128);
    DECLARE @DBMailProfileName nvarchar(128);
    DECLARE @EmailRecipients nvarchar(128);
    DECLARE @EmailCCRecipients nvarchar(128);
    DECLARE @EmailSubject nvarchar(255);
    DECLARE @EmailBody nvarchar(MAX);
    DECLARE @DBAEmail nvarchar(128);
    DECLARE @SQLErrorLogPath nvarchar(256);

    CREATE TABLE #SQLErrorLogPath(
        LogText varchar(8000),
        ContinuationRow tinyint
    );
    INSERT INTO #SQLErrorLogPath EXEC sp_readerrorlog 0,1,'Logging SQL Server messages in file';

    -- identify row
    SET @SQLErrorLogPath = (SELECT LogText FROM #SQLErrorLogPath WHERE LogText LIKE '%Logging SQL Server messages in file%');
    -- remove extra chars
    SET @SQLErrorLogPath = REPLACE(@SQLErrorLogPath, 'Logging SQL Server messages in file', '');
    -- find position of "<drive>:\"
    SET @SQLErrorLogPath = SUBSTRING(@SQLErrorLogPath, PATINDEX('%:\%', @SQLErrorLogPath)-1, LEN(@SQLErrorLogPath));
    -- remove trailing chars
    SET @SQLErrorLogPath = REPLACE(@SQLErrorLogPath, '''.', '');

    -- retrieve the SQL Server instance name (no hard-coding!)
    SET @InstanceName = UPPER(ISNULL(@@SERVERNAME, CAST(SERVERPROPERTY('ServerName') AS nvarchar(128))));

    SET @EmailRecipients = '247support@mycompany.com'; /* ***** REPLACE AS NECESSARY ***** */
    SET @EmailCCRecipients = 'dbateam@mycompany.com'; /* ***** REPLACE AS NECESSARY ***** */
    SET @DBAEmail = 'dbateam@mycompany.com'; /* ***** REPLACE AS NECESSARY ***** */
    SET @EmailSubject = 'SQL Server Cluster Resource ' + @InstanceName + ' Failed-Over';
    SET @EmailBody = 'Dear recipient,

Kindly note that the SQL Server cluster resource ' + @InstanceName + ' is in a failed-over state.

Please take a copy of and review the following error logs, and action accordingly:

 - SQL Server Error Log (' + @SQLErrorLogPath + ')
 - Windows Event Viewer
 - Cluster Log (C:\WINDOWS\CLUSTER\Cluster.log)

Thank you.

DBA Team
My Company Name
 
Email: ' + @DBAEmail + '
URL: http://www.mycompany.com
';

    EXEC [master].[dbo].[sp_send_cdosysmail] 
        @From = @DBAEmail, 
        @To = @EmailRecipients, 
        @Subject = @EmailSubject, 
        @Body = @EmailBody;
    
    DROP TABLE #SQLErrorLogPath;
END;
