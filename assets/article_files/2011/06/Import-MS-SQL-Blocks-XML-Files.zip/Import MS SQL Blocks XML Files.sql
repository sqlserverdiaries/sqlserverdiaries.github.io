USE [tempdb]
GO

-- enable 'xp_cmdshell' option
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
EXEC sp_configure 'xp_cmdshell', 1;
GO
RECONFIGURE;
GO
/*
Configuration option 'show advanced options' changed from 0 to 1. Run the RECONFIGURE statement to install.
Configuration option 'xp_cmdshell' changed from 0 to 1. Run the RECONFIGURE statement to install.
*/

SET NOCOUNT ON;

DECLARE @filepath varchar(2000);
DECLARE @cmd nvarchar(2000);
DECLARE @XMLFileLoop CURSOR;

DECLARE @ServerNameFilter varchar(128);

DECLARE @XMLResult XML;

DECLARE @server_name varchar(128),
        @start_time varchar(20),
        @duration int;

CREATE TABLE #XMLFiles (FilePath varchar(2000)); -- table that holds the XML files to be analysed (full paths)
CREATE TABLE #XMLData (XmlData XML); -- table that holds xml file; recycled with every loop iteration
CREATE TABLE #XMLResults(
    server_name varchar(128),
    start_time varchar(20),
    duration int,
    state varchar(50),
    spid int,
    block_spid int,
    dbname varchar(128),
    wait_time int,
    last_wait_type varchar(100),
    wait_resource varchar(100),
    open_tran_count int,
    status varchar(100),
    host_name varchar(128),
    app_name varchar(1000),
    cmd varchar(100),
    login_name varchar(128),
    cpu bigint,
    physical_io bigint,
    mem_usage int,
    last_batch varchar(20),
    sql_query varchar(2000)
); -- table that holds the blocking information extracted from the xml files


-- a server name filter - can be a regular expression supported by the LIKE statement
SET @ServerNameFilter = '%';

-- retrieve list of files to analyse
SET @cmd = 'dir /b /s "D:\TEMP\xml_sample\2010*.xml"';
INSERT INTO #XMLFiles(FilePath) EXEC xp_cmdshell @cmd;


-- ***** START LOOP HERE *****
SET @XMLFileLoop = CURSOR FOR
    SELECT FilePath FROM #XMLFiles;
OPEN @XMLFileLoop;
FETCH NEXT FROM @XMLFileLoop INTO @filepath
WHILE (@@FETCH_STATUS = 0)
BEGIN
    SET @cmd = 'SELECT CAST(BulkColumn AS XML)
FROM OPENROWSET(
    BULK ''' + @filepath + ''',
    SINGLE_BLOB) AS x;'

    INSERT INTO #XMLData(XMLData) EXEC sp_executesql @cmd;

    -- read the xml file to a variable
    SELECT @XMLResult = XMLData FROM #XMLData;

    -- retrieve server info
    SELECT 
        @server_name = T.sqlblock.value('@server_name','varchar(128)'),
        @start_time = T.sqlblock.value('@start_time','varchar(20)'),
        @duration = T.sqlblock.value('@duration','int')
    FROM @XMLResult.nodes('/snapshot') T (sqlblock);

    -- filter...
    IF @server_name LIKE @ServerNameFilter
    BEGIN
        -- retrieve blocking process info
        INSERT INTO #XMLResults
        SELECT 
            @server_name AS [server_name],
            @start_time AS [start_time],
            @duration AS [duration],
            T.sqlblock.value('@state', 'varchar(50)') AS [state],
            T.sqlblock.value('@spid', 'int') AS [spid],
            T.sqlblock.value('@block_spid', 'int') AS [block_spid],
            T.sqlblock.value('@dbname', 'varchar(128)') AS [dbname],
            T.sqlblock.value('@wait_time', 'int') AS [wait_time],
            T.sqlblock.value('@last_wait_type', 'varchar(100)') AS [last_wait_type],
            T.sqlblock.value('@wait_resource', 'varchar(100)') AS [wait_resource],
            T.sqlblock.value('@open_tran_count', 'int') AS [open_tran_count],
            T.sqlblock.value('@status', 'varchar(100)') AS [status],
            T.sqlblock.value('@host_name', 'varchar(128)') AS [host_name],
            T.sqlblock.value('@app_name', 'varchar(1000)') AS [app_name],
            T.sqlblock.value('@cmd', 'varchar(100)') AS [cmd],
            T.sqlblock.value('@login_name', 'varchar(128)') AS [login_name],
            T.sqlblock.value('@cpu', 'bigint') AS [cpu],
            T.sqlblock.value('@physical_io', 'bigint') AS [physical_io],
            T.sqlblock.value('@mem_usage', 'int') AS [mem_usage],
            T.sqlblock.value('@last_batch', 'varchar(20)') AS [last_batch],
            T.sqlblock.value('sql[1]','varchar(2000)') AS [sql_query]
        FROM @XMLResult.nodes('/snapshot/process') T (sqlblock);
        
        PRINT @filepath;
    END;

    -- recycle table
    TRUNCATE TABLE #XMLData;

    FETCH NEXT FROM @XMLFileLoop INTO @filepath
END
CLOSE @XMLFileLoop;
DEALLOCATE @XMLFileLoop;
-- ***** END LOOP HERE *****

-- results
SELECT * 
FROM #XMLResults
ORDER BY [server_name], [dbname], [start_time];

-- clean up
DROP TABLE #XMLData;
DROP TABLE #XMLFiles;
DROP TABLE #XMLResults;

-- disable 'xp_cmdshell' option
EXEC sp_configure 'xp_cmdshell', 0;
GO
RECONFIGURE;
GO
EXEC sp_configure 'show advanced options', 0;
GO
RECONFIGURE;
GO
/*
Configuration option 'xp_cmdshell' changed from 1 to 0. Run the RECONFIGURE statement to install.
Configuration option 'show advanced options' changed from 1 to 0. Run the RECONFIGURE statement to install.
*/