USE [master]
GO

-- verify that the database owner is set to "sa"
IF NOT EXISTS(
    SELECT 1 FROM sys.databases 
    WHERE [name] = 'AdventureWorks' AND owner_sid = 0x01)
BEGIN
    ALTER AUTHORIZATION ON DATABASE::[AdventureWorks] TO [sa];
END
GO

-- verify that the TRUSTWORTH database option is set to ON
IF NOT EXISTS(
    SELECT 1 FROM sys.databases 
    WHERE [name] = 'AdventureWorks' AND is_trustworthy_on = 1)
BEGIN
    ALTER DATABASE [AdventureWorks] SET TRUSTWORTHY ON;
END
GO


USE [AdventureWorks]
GO

-- verify that the database role "db_passwordmanager" is created in the database
IF NOT EXISTS(
    SELECT 1 FROM sys.database_principals 
    WHERE [type_desc] = 'DATABASE_ROLE' AND [name] = 'db_passwordmanager')
BEGIN
    CREATE ROLE [db_passwordmanager];
END
GO


/*
----------------------------------------------------------------------------
-- Object Name:             dbo.usp_alterloginpassword
-- Project:                 DBA Toolbox
-- Business Process:        User Management
-- Purpose:                 Password changes for logins
-- Detailed Description:    Change password for valid database users only
-- Database:                Where the functionality is required
-- Dependent Objects:       Requires that the TRUSTWORTHY database option is set to ON
-- Called By:               SysAdmin, other custom database roles as required
--
--------------------------------------------------------------------------------------
-- Rev   | CMR      | Date Modified  | Developer             | Change Summary
--------------------------------------------------------------------------------------
--   1.0 |          | 21/07/2009     | Reuben Sultana        | First implementation
--   1.1 |          | 25/08/2012     | Reuben Sultana        | Added password to login comparison validation
--       |          |                |                       |
--
*/
CREATE PROCEDURE [dbo].[usp_alterloginpassword]
    @login nvarchar(8),
    @newpwd nvarchar(30)
WITH EXECUTE AS OWNER
AS
SET NOCOUNT ON

-- ***** LOGIN VALIDATIONS *****
-- check if a login was passed
IF (@login IS NULL)
BEGIN
	RAISERROR('The login parameter cannot be null.',16,1);
	RETURN (1);
END;

-- login has to be 8 character long
IF (LEN(@login) <> 8)
BEGIN
	RAISERROR('The login parameter has to be eight characters long.',16,1);
	RETURN (1);
END;

-- check if login has a valid format
IF (@login NOT LIKE '[A-Z][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9]')
BEGIN
	RAISERROR('The login structure ''%s'' is not valid.',16,1,@login);
	RETURN (1);
END;

-- check if the login is a valid database user
IF NOT EXISTS (
    SELECT 1 FROM sys.database_principals WHERE [type] = 'S' -- SQL user
    AND [name] = @login)
BEGIN
	RAISERROR('The login ''%s'' is not a valid database user.',16,1,@login);
	RETURN (1);
END;

-- check if the [db_passwordmanager] role exists
IF NOT EXISTS(
    SELECT 1 FROM sys.database_principals WHERE [type] = 'R' -- Database role
    AND [name] = 'db_passwordmanager' AND is_fixed_role = 0)
BEGIN
	RAISERROR('This database is not configured for password management functions.',16,1);
	RETURN (1);
END;

-- set the execution context to the caller of the module to retrieve the login
EXECUTE AS CALLER;
DECLARE @originallogin nvarchar(128);
SET @originallogin = SYSTEM_USER;

-- check if the currently logged on user is a member of the allowed role/s
IF ((IS_SRVROLEMEMBER('sysadmin') + IS_SRVROLEMEMBER('securityadmin') + 
    IS_MEMBER('db_owner') + IS_MEMBER('db_passwordmanager')) = 0)
BEGIN
	RAISERROR('The login ''%s'' is not authorised to carry out password management functions.',16,1, @originallogin);
	RETURN (1);
END

-- reset the execution context
REVERT;


-- ***** PASSWORD VALIDATIONS *****
-- check if password is empty
IF (@newpwd IS NULL)
BEGIN
	RAISERROR('Password parameter cannot be NULL.',16,1);
	RETURN (1);
END;

-- check minimum password length
IF (LEN(@newpwd) < 8)
BEGIN
    RAISERROR('Password has to be at least eight characters long.',16,1);
	RETURN (1);
END;

-- version 1.1 fix: compare password to login
IF (@newpwd = @login)
BEGIN
	RAISERROR('The password cannot be identical to the login name.',16,1);
	RETURN (1);
END;


-- ***** OTHER CUSTOM VALIDATIONS *****

-- ***** END CUSTOM VALIDATIONS *****


-- ***** CHANGE PASSWORD *****
DECLARE @cmd nvarchar(255);
SET @cmd = N'ALTER LOGIN ' + QUOTENAME(@login, '[') + ' WITH PASSWORD = ''' + @newpwd + ''', CHECK_POLICY = ON;';

BEGIN TRY
    -- try changing the password
    EXEC sp_executesql @cmd;

    -- ***** ADD CUSTOM CODE HERE *****
    
    -- ***** END CUSTOM CODE *****

    RAISERROR('Password changed successfully for login ''%s'' by ''%s''.',-1,-1,@login,@originallogin) WITH LOG;
END TRY
BEGIN CATCH
    -- XACT_STATE = 0 means there is no transaction and a commit or rollback operation would generate an error
    IF (XACT_STATE() <> 0)
        ROLLBACK TRANSACTION;

    DECLARE @ErrorMessage nvarchar(4000);
    DECLARE @ErrorSeverity int;
    DECLARE @ErrorState int;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    RAISERROR (@ErrorMessage,   -- Message text.
               @ErrorSeverity,  -- Severity.
               @ErrorState      -- State.
               );
END CATCH

GO
