USE [master]
GO

IF  OBJECT_ID(N'dbo.usp_database_getpermissions') IS NOT NULL
    DROP PROCEDURE [dbo].[usp_database_getpermissions]
GO

CREATE PROCEDURE [dbo].[usp_database_getpermissions]
    @databasename sysname,
    @loginname sysname = NULL
AS
SET NOCOUNT ON

DECLARE @sql nvarchar(4000)
DECLARE @params nvarchar(150);

IF NOT EXISTS(SELECT [name] FROM [sys].[databases] WHERE [name] = @databasename)
BEGIN
    RAISERROR('The database ''%s'' does not exist!', 16, 1, @databasename);
    RETURN
END

SET @params = N'@loginname sysname';

-- database permissions
SET @sql = 'SELECT 
    [prin].[name] [database_principal], 
    [sec].[state_desc] + '' '' + [sec].[permission_name] [permission_name]
FROM [@1].[sys].[database_permissions] [sec]
  INNER JOIN [@1].[sys].[database_principals] [prin] ON [sec].[grantee_principal_id] = [prin].[principal_id]
WHERE [prin].[name] LIKE ISNULL(@loginname, ''%'')
AND [sec].[class] = 0
ORDER BY [database_principal], [permission_name]';

SET @sql = REPLACE(@sql, '@1', @databasename)

EXEC sp_executesql @sql, @params, @loginname

-- fixed roles
SET @sql = 'SELECT 
    [u].[name] [member_name],
    [g].[name] [database_role]
FROM [@1].[sys].[database_role_members] [m]
    INNER JOIN [@1].[sys].[database_principals] [u] ON [u].[principal_id] = [m].[member_principal_id]
    INNER JOIN [@1].[sys].[database_principals] [g] ON [g].[principal_id] = [m].[role_principal_id]
WHERE [u].[name] LIKE ISNULL(@loginname, ''%'')
ORDER BY [member_name], [database_role]';

SET @sql = REPLACE(@sql, '@1', @databasename)

EXEC sp_executesql @sql, @params, @loginname

GO
