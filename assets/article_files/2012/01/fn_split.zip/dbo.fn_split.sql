
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn_split]') 
            AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
    DROP FUNCTION [dbo].[fn_split];
GO

CREATE FUNCTION dbo.fn_split (
    @p_sDelimitedText nvarchar(max), 
    @p_sDelimiter nvarchar(1) 
)
RETURNS @ReturnTable TABLE (
    RowNumber int IDENTITY(1,1),
	ReturnCol nvarchar(max)
)
AS
BEGIN
    DECLARE @XMLData XML;
    SELECT @XMLData = CAST('<d>' + REPLACE(@p_sDelimitedText, @p_sDelimiter, '</d><d>') + '</d>' AS XML);

    INSERT INTO @ReturnTable(ReturnCol)
        SELECT XMLDataTable.split.value('.', 'nvarchar(max)') AS data
        FROM @XMLData.nodes('/d') XMLDataTable(split)

    RETURN
END
GO

-- TEST
/*
DECLARE @text NVARCHAR(max)
SELECT @text = REPLICATE('ab,', 300) + 'ab'

SELECT * FROM dbo.[fn_split](@text, ',')
*/