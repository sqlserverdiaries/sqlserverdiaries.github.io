USE [master]
GO

DECLARE @ServerName nvarchar(128),
        @DatabaseName nvarchar(128),
        @WindowsVersion nvarchar(128);
        
DECLARE @SQLcmd nvarchar(2000);

DECLARE @low nvarchar(11);

CREATE TABLE #XPMSVER (
    [Index] int,
    [Name] nvarchar(128),
    [Internal_Value] nvarchar(128),
    [Character_Value] nvarchar(128)
);

CREATE TABLE #databaselist (
    [ServerName] nvarchar(128),
    [ProductVersion] nvarchar(128),
    [WindowsVersion] nvarchar(128),
    [DatabaseName] nvarchar(128),
    [DatabaseSizeMB] numeric(10,2)
);

INSERT INTO #XPMSVER EXEC xp_msver 'WindowsVersion';

SELECT @WindowsVersion = CASE
        WHEN [Character_Value] LIKE '5.0%' THEN '2000'
        WHEN [Character_Value] LIKE '5.2%' THEN '2003'
        WHEN [Character_Value] LIKE '6.0%' THEN '2008'
        WHEN [Character_Value] LIKE '6.1%' THEN '2008 R2'
    END
FROM #XPMSVER;

INSERT INTO #databaselist(ServerName, ProductVersion, WindowsVersion, DatabaseName)
SELECT 
    CAST(@@SERVERNAME AS nvarchar(128)), 
    CASE 
        WHEN CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(128)) LIKE '8.%' THEN '2000'
        WHEN CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(128)) LIKE '9.%' THEN '2005'
        WHEN CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(128)) LIKE '10.0%' THEN '2008'
        WHEN CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(128)) LIKE '10.5%' THEN '2008 R2'
    END,
    @WindowsVersion,
    db.[name]
FROM sysdatabases db
WHERE db.[name] NOT IN ('master', 'model', 'msdb', 'tempdb', 'Northwind', 'pubs')
AND db.[name] NOT LIKE 'AdventureWorks%'
AND db.[name] NOT LIKE 'ReportServer%';


SET @low = (
    SELECT CONVERT(varchar(11),low) FROM dbo.spt_values
    WHERE [type] = N'E' AND [number] = 1);

DECLARE databaseinfo CURSOR GLOBAL FOR
	SELECT ServerName, DatabaseName from #databaselist
OPEN databaseinfo;
FETCH databaseinfo INTO @ServerName, @DatabaseName;
WHILE (@@FETCH_STATUS >= 0)
BEGIN
	IF (HAS_DBACCESS(@DatabaseName) <> 1)
	BEGIN
        DELETE #databaselist WHERE CURRENT OF databaseinfo
	    RAISERROR(15622,-1,-1, @DatabaseName)
	END
	ELSE
    BEGIN
	    SET @SQLcmd = '
UPDATE #databaselist SET [DatabaseSizeMB] = (select str(convert(dec(15),sum(size))* ' + @low + '/ 1048576,10,2) FROM '
    + QUOTENAME(@DatabaseName, N'[') + N'.dbo.sysfiles) WHERE CURRENT OF databaseinfo';

        PRINT @SQLcmd;

	    EXEC sp_executesql @SQLcmd;
    END
	FETCH databaseinfo INTO @ServerName, @DatabaseName;
END
CLOSE databaseinfo;
DEALLOCATE databaseinfo;


SELECT 
    UPPER([ServerName]) AS [Server Name],
    [ProductVersion] AS [SQL Server Version], 
    [WindowsVersion] AS [Windows Version], 
    [DatabaseName] AS [Database Name],
    [DatabaseSizeMB] AS [Database Size MB]
FROM #databaselist db;

DROP TABLE #XPMSVER;
DROP TABLE #databaselist;
