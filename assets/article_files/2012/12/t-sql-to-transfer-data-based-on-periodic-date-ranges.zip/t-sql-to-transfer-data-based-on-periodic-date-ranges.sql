USE [master]
GO

SET NOCOUNT ON;
DECLARE @StartDate datetime;
DECLARE @EndDate datetime;
DECLARE @DateRangeCursor CURSOR;
DECLARE @msg nvarchar(500);
DECLARE @RecordsAffected bigint;

-- set date range here
SET @StartDate = CONVERT(datetime, '2012-11-01', 102);
SET @EndDate   = CONVERT(datetime, '2012-12-01', 102);

/*
-- get daily itemcount within range
-- SQL Server 2005 version
SELECT 
    CONVERT(datetime, CONVERT(varchar(10), [DateColumn], 120)) AS [ItemDate], 
    COUNT(*) AS [ItemCount]
FROM [SourceDatabase].[dbo].[SourceTable] WITH (NOLOCK)
WHERE [DateColumn] BETWEEN @StartDate AND @EndDate
GROUP BY CONVERT(datetime, CONVERT(varchar(10), [DateColumn], 120));

-- SQL Server 2008 and later version
SELECT 
    CONVERT(date, [DateColumn]) AS [ItemDate], 
    COUNT(*) AS [ItemCount]
FROM [SourceDatabase].[dbo].[SourceTable] WITH (NOLOCK)
WHERE [DateColumn] BETWEEN @StartDate AND @EndDate
GROUP BY CONVERT(date, [DateColumn]);
*/

-- generate date ranges
SET @DateRangeCursor = CURSOR FOR 
    WITH cteDateRange
    AS (
        SELECT @StartDate AS dt
        UNION ALL
        SELECT DATEADD(day, 1, dt)
        FROM cteDateRange 
        WHERE dt < @EndDate
    )
    SELECT d2.dt AS StartDate, d1.dt AS EndDate
    FROM cteDateRange d1
        INNER JOIN cteDateRange d2 ON d1.dt = DATEADD(day, 1, d2.dt)
    ORDER BY d1.dt ASC;

-- loop
OPEN @DateRangeCursor
FETCH NEXT FROM @DateRangeCursor INTO @StartDate, @EndDate;
WHILE @@FETCH_STATUS = 0
BEGIN
    -- display which day is being processed
    SET @msg = CONVERT(varchar(19), CURRENT_TIMESTAMP, 120) + ' : Processing range ' + CONVERT(varchar(19), @StartDate, 120) + ' - ' + CONVERT(varchar(19), @EndDate, 120);
    RAISERROR('%s', 1, 1, @msg) WITH NOWAIT;

    -- transfer data
    INSERT INTO [DestinationDatabase].[dbo].[DestinationTable] (
	    [RecordID]
	    ,[RowNumber]
	    ,[Status]
	    ,[ErrorMessage]
	    ,[EnteredDate]
	    ,[Country]
	    ,[IsDeleted]
	    ,[SessionID]
	    ,[UniqueID]
	    ,[DateColumn])
    SELECT
	    [RecordID]
	    ,[RowNumber]
	    ,[Status]
	    ,[ErrorMessage]
	    ,[EnteredDate]
	    ,[Country]
	    ,[IsDeleted]
	    ,[SessionID]
	    ,[UniqueID]
	    ,[DateColumn]
    FROM [SourceDatabase].[dbo].[SourceTable] WITH (NOLOCK)
    WHERE [DateColumn] BETWEEN @StartDate AND @EndDate;
    
    -- display rowcount
    SET @RecordsAffected = @@ROWCOUNT;
    RAISERROR('%I64d records affected', 1, 1, @RecordsAffected) WITH NOWAIT;
    
    -- next item in loop
    FETCH NEXT FROM @DateRangeCursor INTO @StartDate, @EndDate;
END
CLOSE @DateRangeCursor;
DEALLOCATE @DateRangeCursor;
