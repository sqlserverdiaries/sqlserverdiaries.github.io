/*
Notes:

Replace "MyDatabase" with the name of the database that will store the SSIS params table
Replace "MyCertificate" with the name you'd like to give to the certificate
When creating the certificate set values for subject and date range as necessary (see below)
Replace "certificate-username" with the application username
*/

USE [MyDatabase]
GO

CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'P@ssw0rd';
GO


-- Create certificate: set values for subject and date range as necessary
CREATE CERTIFICATE MyCertificate AUTHORIZATION [dbo]
WITH SUBJECT = 'Database certificate', 
    START_DATE = '2012-06-23 00:00:00.000',
    EXPIRY_DATE = '9999-12-31 23:59:59.997'; -- does not expire
GO


-- Creating a schema to separate objects
CREATE SCHEMA [SSIS]
GO


-- table that will store configuration parameter values
CREATE TABLE [SSIS].[tb_ConfigurationsE](
	[sc_config_filter] [nvarchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[sc_config_value] [varbinary](512) NULL, -- column storing encrypted data
	[sc_package_path] [nvarchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[sc_config_value_type] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [TABLES]
GO


-- a user which does not have a login; i.e. cannot authenticate
CREATE USER [certificate-username] WITHOUT LOGIN
GO


-- the function that DECRYPTS
CREATE FUNCTION [dbo].[udf_decryptvaluebycert] (
    @encryptedText varbinary(8000),
    @certificateName nvarchar(128)
)
RETURNS nvarchar(4000) 
WITH EXEC AS 'certificate-username'
BEGIN
    DECLARE @DecryptedText AS NVARCHAR(4000)

    SET @DecryptedText = CONVERT(NVARCHAR(4000), DECRYPTBYCERT(CERT_ID(@certificateName),@encryptedText))

    RETURN (@DecryptedText);
END

GO


-- the view that will be used as an abstraction layer
CREATE VIEW [SSIS].[vw_ConfigurationsE]
AS
SELECT [sc_config_filter] AS ConfigurationFilter,
       [dbo].[udf_decryptvaluebycert] ([sc_config_value], 'MyCertificate') AS ConfiguredValue,
       [sc_package_path] AS PackagePath,
       [sc_config_value_type] AS ConfiguredValueType
FROM   [SSIS].[tb_ConfigurationsE]

GO


-- trigger on the view that replaces INSERT and UPDATE DML operations
-- note that certificate name is "hard-coded"
CREATE TRIGGER [SSIS].[trg_ConfigurationsE]
    ON [SSIS].[vw_ConfigurationsE]
    INSTEAD OF INSERT, UPDATE
AS
SET NOCOUNT ON;

-- check for updates
IF EXISTS(SELECT * FROM deleted)
BEGIN
    UPDATE SSIS.tb_ConfigurationsE
    SET sc_config_filter        = i.ConfigurationFilter,       
        sc_config_value         = ENCRYPTBYCERT(CERT_ID('MyCertificate'), i.ConfiguredValue),
        sc_package_path         = i.PackagePath,
        sc_config_value_type    = i.ConfiguredValueType
    FROM inserted i
        INNER JOIN SSIS.tb_ConfigurationsE se ON se.sc_config_filter = i.ConfigurationFilter 
    WHERE se.sc_package_path = i.PackagePath 
    AND se.sc_config_value_type = i.ConfiguredValueType
END   
ELSE
-- inserts only
BEGIN
    INSERT SSIS.tb_ConfigurationsE (
        sc_config_filter, sc_config_value, sc_package_path, sc_config_value_type)
    SELECT i.ConfigurationFilter,
        ENCRYPTBYCERT(CERT_ID('MyCertificate'), i.ConfiguredValue),
        i.PackagePath, 
        i.ConfiguredValueType
    FROM inserted i
END

GO


-- to allow the database user defined to use the certificate
GRANT CONTROL ON CERTIFICATE::MyCertificate TO [certificate-username]
GO
