SET NOCOUNT ON

DECLARE @objectID int;
DECLARE @SQLServerVersion INT;

--SET @objectID = 41207347;
SET @SQLServerVersion = CAST(DATABASEPROPERTYEX('master', 'Version') AS int);

SELECT 'USE ' + QUOTENAME(DB_NAME(), '[') + '
GO';

SELECT 
    CASE WHEN ix.[is_primary_key]=1 THEN 'ALTER TABLE [' + OBJECT_SCHEMA_NAME(ix.[object_id]) + '].[' + OBJECT_NAME(ix.[object_id]) + '] ADD 
CONSTRAINT [' + ISNULL(ix.[name], '') + '] PRIMARY KEY ' + ix.[type_desc] COLLATE SQL_Latin1_General_CP1_CI_AS + ' ' 

        ELSE 'CREATE ' + 
            CASE WHEN (ix.[is_unique]=1 AND ix.[type]>1) THEN 'UNIQUE ' + ix.[type_desc] COLLATE SQL_Latin1_General_CP1_CI_AS -- [UNIQUE] CLUSTERED
                ELSE ix.[type_desc] COLLATE SQL_Latin1_General_CP1_CI_AS -- NONCLUSTERED
            END + ' INDEX [' + ISNULL(ix.[name], '') + '] ON [' + OBJECT_SCHEMA_NAME(ix.[object_id]) + '].[' + OBJECT_NAME(ix.[object_id]) + '] '
    END +

        -- indexed_columns
        '(' + ISNULL(REPLACE( REPLACE( REPLACE(
        (   
            SELECT c.[name] + (CASE WHEN sic.[is_descending_key]=0 THEN ' ASC' ELSE ' DESC' END) AS 'columnName'
            FROM sys.index_columns AS sic
                INNER JOIN sys.columns AS c ON c.[column_id] = sic.[column_id] AND c.[object_id] = sic.[object_id]
            WHERE sic.[object_id] = ix.[object_id]
            AND sic.[index_id] = ix.[index_id]
            AND sic.[is_included_column] = 0
            ORDER BY sic.[index_column_id]
            FOR XML RAW)
            , '"/><row columnName="', ', ') -- REPLACE 3
            , '<row columnName="', '') -- REPLACE 2
            , '"/>', ''), '') + -- REPLACE 1 & ISNULL
        ') ' +
        
        -- included columns
        ISNULL('INCLUDE (' + REPLACE( REPLACE( REPLACE(
        (   
            SELECT c.[name] AS 'columnName'
            FROM sys.index_columns AS sic
                INNER JOIN sys.columns AS c ON c.[column_id] = sic.[column_id] AND c.[object_id] = sic.[object_id]
            WHERE sic.[object_id] = ix.[object_id]
            AND sic.[index_id] = ix.[index_id]
            AND sic.[is_included_column] = 1
            ORDER BY sic.[index_column_id]
            FOR XML RAW)
            , '"/><row columnName="', ', ') -- REPLACE 3
            , '<row columnName="', '') -- REPLACE 2
            , '"/>', '') + ') ' -- REPLACE 1 
        , '') + -- ISNULL
        
        -- filtered columns
        CASE @SQLServerVersion
            WHEN 611 THEN '' -- 2005
            ELSE ISNULL('WHERE ' + ix.[filter_definition], '') -- 2008 and later
        END +
'
WITH (
    PAD_INDEX = ' + CASE WHEN ix.[is_padded] = 0 THEN 'OFF' ELSE 'ON' END + ', STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, IGNORE_DUP_KEY = ' + CASE WHEN ix.[ignore_dup_key] = 0 THEN 'OFF' ELSE 'ON' END + ', 
    ONLINE = OFF, ALLOW_ROW_LOCKS = ' + CASE WHEN ix.[allow_row_locks] = 0 THEN 'OFF' ELSE 'ON' END + ', ALLOW_PAGE_LOCKS = ' + CASE WHEN ix.[allow_page_locks] = 0 THEN 'OFF' ELSE 'ON' END + ', FILLFACTOR = 90
    ) ON [INDEXES];

'

FROM sys.indexes AS ix
    INNER JOIN sys.tables AS st ON ix.[object_id] = st.[object_id]

WHERE ix.[index_id] > 0 -- exclude heap
AND ix.[object_id] = ISNULL(@objectID, ix.[object_id])

GROUP BY 
    st.name
    , ISNULL(ix.[name], '')
    , ix.[object_id]
    , ix.[index_id]
    , ix.[is_primary_key]
    , ix.[is_unique]
    , ix.[type]
    , ix.[type_desc]
    , ix.[is_padded]
    , ix.[ignore_dup_key]
    , ix.[allow_row_locks]
    , ix.[allow_page_locks]
    , ix.[filter_definition]
    
ORDER BY 
    st.[name]
    , ix.[index_id];


/*
DECLARE @objectID INT --= 41207347;
 
WITH indexCTE(partition_scheme_name
            , partition_function_name
            , data_space_id)
AS (
SELECT 
    sps.name
    , spf.name
    , sps.data_space_id
FROM sys.partition_schemes AS sps
    INNER JOIN sys.partition_functions AS spf ON sps.function_id = spf.function_id
)
 
SELECT st.name AS 'table_name'
    , ISNULL(ix.name, '') AS 'index_name'
    , ix.object_id
    , ix.index_id
	, CAST(
        CASE WHEN ix.index_id = 1 
                THEN 'clustered' 
            WHEN ix.index_id =0
                THEN 'heap'
            ELSE 'nonclustered' END
		+ CASE WHEN ix.ignore_dup_key <> 0 
            THEN ', ignore duplicate keys' 
                ELSE '' END
		+ CASE WHEN ix.is_unique <> 0 
            THEN ', unique' 
                ELSE '' END
		+ CASE WHEN ix.is_primary_key <> 0 
            THEN ', primary key' ELSE '' END AS VARCHAR(210)
        ) AS 'index_description'
    , ISNULL(REPLACE( REPLACE( REPLACE(
        (   
            SELECT c.name AS 'columnName'
            FROM sys.index_columns AS sic
            JOIN sys.columns AS c 
                ON c.column_id = sic.column_id 
                AND c.object_id = sic.object_id
            WHERE sic.object_id = ix.object_id
                AND sic.index_id = ix.index_id
                AND is_included_column = 0
            ORDER BY sic.index_column_id
            FOR XML RAW)
            , '"/><row columnName="', ', ')
            , '<row columnName="', '')
            , '"/>', ''), '')
        AS 'indexed_columns'
    , ISNULL(REPLACE( REPLACE( REPLACE(
        (   
            SELECT c.name AS 'columnName'
            FROM sys.index_columns AS sic
            JOIN sys.columns AS c 
                ON c.column_id = sic.column_id 
                AND c.object_id = sic.object_id
            WHERE sic.object_id = ix.object_id
                AND sic.index_id = ix.index_id
                AND is_included_column = 1
            ORDER BY sic.index_column_id
            FOR XML RAW)
            , '"/><row columnName="', ', ')
            , '<row columnName="', '')
            , '"/>', ''), '')
        AS 'included_columns'
    , ix.filter_definition
    , ISNULL(cte.partition_scheme_name, '') AS 'partition_scheme_name'
    , COUNT(partition_number) AS 'partition_count'
    , SUM(ROWS) AS 'row_count'

FROM sys.indexes AS ix
    INNER JOIN sys.partitions AS sp ON ix.object_id = sp.object_id AND ix.index_id = sp.index_id
    INNER JOIN sys.tables AS st ON ix.object_id = st.object_id
    LEFT JOIN indexCTE AS cte ON ix.data_space_id = cte.data_space_id

WHERE ix.object_id = ISNULL(@objectID, ix.object_id)

GROUP BY 
    st.name
    , ISNULL(ix.name, '')
    , ix.object_id
    , ix.index_id
	, CAST(
        CASE WHEN ix.index_id = 1 
                THEN 'clustered' 
            WHEN ix.index_id =0
                THEN 'heap'
            ELSE 'nonclustered' END
		+ CASE WHEN ix.ignore_dup_key <> 0 
            THEN ', ignore duplicate keys' 
                ELSE '' END
		+ CASE WHEN ix.is_unique <> 0 
            THEN ', unique' 
                ELSE '' END
		+ CASE WHEN ix.is_primary_key <> 0 
            THEN ', primary key' ELSE '' END AS VARCHAR(210)
        )
    , ix.filter_definition
    , ISNULL(cte.partition_scheme_name, '')
    , ISNULL(cte.partition_function_name, '')

ORDER BY 
    table_name
    , ix.index_id;
*/