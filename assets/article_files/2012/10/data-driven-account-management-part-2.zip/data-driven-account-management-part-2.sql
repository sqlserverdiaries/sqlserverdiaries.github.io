USE MyDatabase
GO

/* Create the data store objects required for this example */
CREATE TABLE FunctionList (
	fnl_pk int IDENTITY(1,1) NOT NULL,
    fnl_friendlyname nvarchar(50) NOT NULL,
    fnl_objectname nvarchar(128) NOT NULL,
	fnl_status bit NOT NULL DEFAULT (1)
);

CREATE TABLE PermissionGranted (
	pmg_pk int IDENTITY(1,1) NOT NULL,
	pmg_fnl_fk int NOT NULL,
	pmg_rol_fk int NOT NULL,
	pmg_status bit NOT NULL DEFAULT (1)
);


/* Primary Key constraints */
ALTER TABLE FunctionList 
    ADD CONSTRAINT PK_FunctionList PRIMARY KEY CLUSTERED (fnl_pk ASC)
ALTER TABLE PermissionGranted 
    ADD CONSTRAINT PK_PermissionGranted PRIMARY KEY CLUSTERED (pmg_pk ASC)
GO


/* Foreign Key constraints */
ALTER TABLE PermissionGranted WITH CHECK 
    ADD CONSTRAINT [FK_PermissionGranted_Function] FOREIGN KEY (pmg_fnl_fk) 
    REFERENCES FunctionList (fnl_pk) ON UPDATE NO ACTION ON DELETE NO ACTION 
ALTER TABLE RoleMembers WITH CHECK 
    ADD CONSTRAINT [FK_PermissionGranted_Role] FOREIGN KEY (pmg_rol_fk) 
    REFERENCES Roles (rol_pk) ON UPDATE NO ACTION ON DELETE NO ACTION 
GO


/* Unique Key constraints */
ALTER TABLE FunctionList 
    ADD CONSTRAINT UNQ_FunctionList_Name UNIQUE (fnl_friendlyname)
ALTER TABLE FunctionList 
    ADD CONSTRAINT UNQ_FunctionList_Object UNIQUE (fnl_objectname)
ALTER TABLE PermissionGranted 
    ADD CONSTRAINT UNQ_PermissionGranted_Link UNIQUE (pmg_fnl_fk, pmg_rol_fk)
GO


/* Procedure to grant permission to a Database Role */
IF OBJECT_ID('dbo.GrantRolePermission') IS NOT NULL
    DROP PROCEDURE [dbo].[GrantRolePermission]
GO

CREATE PROCEDURE [dbo].[GrantRolePermission]
    @RoleName nvarchar(12),
	@PermissionName nvarchar(50)
WITH EXECUTE AS OWNER
AS
BEGIN
    DECLARE @SQLcmd nvarchar(2000);
    DECLARE @DatabaseName nvarchar(128);
    DECLARE @ErroMessage nvarchar(4000);

    SET @SQLcmd = '';
    SET @DatabaseName = DB_NAME();
    SET @ErroMessage = '';
    
	DECLARE @ObjectName nvarchar(128);
	
	SET @ObjectName = (SELECT fnl_objectname FROM FunctionList WHERE fnl_friendlyname = @PermissionName);
	
    BEGIN TRY
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF (EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''DATABASE_ROLE'' AND [name] = ''' + @RoleName + ''') 
AND EXISTS(SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) + ''.'' + [name] = ''' + @ObjectName + '''))
    GRANT EXECUTE ON ' + @ObjectName + ' TO ' + QUOTENAME(@RoleName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
    END TRY
    BEGIN CATCH
        
        RAISERROR(@ErroMessage, 16, 1);
    END CATCH
END
GO

/*
EXEC [dbo].[GrantRolePermission] 'Role001', 'Create Invoice';
*/



/* Procedure to revoke permission to a Database Role */
IF OBJECT_ID('dbo.RevokeRolePermission') IS NOT NULL
    DROP PROCEDURE [dbo].[RevokeRolePermission]
GO

CREATE PROCEDURE [dbo].[RevokeRolePermission]
    @RoleName nvarchar(12),
	@PermissionName nvarchar(50)
WITH EXECUTE AS OWNER
AS
BEGIN
    DECLARE @SQLcmd nvarchar(2000);
    DECLARE @DatabaseName nvarchar(128);
    DECLARE @ErroMessage nvarchar(4000);

    SET @SQLcmd = '';
    SET @DatabaseName = DB_NAME();
    SET @ErroMessage = '';
    
	DECLARE @ObjectName nvarchar(128);
	
	SET @ObjectName = (SELECT fnl_objectname FROM FunctionList WHERE fnl_friendlyname = @PermissionName);
	
    BEGIN TRY
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF (EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''DATABASE_ROLE'' AND [name] = ''' + @RoleName + ''') 
AND EXISTS(SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) + ''.'' + [name] = ''' + @ObjectName + '''))
    REVOKE EXECUTE ON ' + @ObjectName + ' TO ' + QUOTENAME(@RoleName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
    END TRY
    BEGIN CATCH
        
        RAISERROR(@ErroMessage, 16, 1);
    END CATCH
END
GO

/*
EXEC [dbo].[RevokeRolePermission] 'Role001', 'Create Invoice';
*/


/* Trigger fired on insert action in the PermissionGranted table */
IF EXISTS(
    SELECT 1 FROM sys.tables tb 
        INNER JOIN sys.triggers tr ON tr.parent_id = tb.object_id
        INNER JOIN sys.schemas s ON tb.schema_id = s.schema_id
    WHERE tb.name = 'PermissionGranted' AND s.name = 'dbo'
    AND tr.type = 'TR' AND tr.name = 'trg_INS_Permission'
    )
DROP TRIGGER [trg_INS_Permission]
GO

CREATE TRIGGER [trg_INS_Permission] ON [dbo].[PermissionGranted]
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @RoleName nvarchar(12),
            @PermissionName nvarchar(50);
    DECLARE @CursorData CURSOR;
    
    -- process only those which have been inserted with status = 1
    IF EXISTS (SELECT 1 FROM inserted i WHERE i.pmg_status = 1)
    BEGIN
        -- a cursor has to be used to cater for multiple inserts in one batch (e.g. INSERT INTO...SELECT...)
        SET @CursorData = CURSOR FAST_FORWARD FOR
            SELECT r.rol_name, f.fnl_objectname
            FROM inserted i 
                INNER JOIN FunctionList f ON f.fnl_pk = pmg_fnl_fk
                INNER JOIN Roles r ON r.rol_pk = pmg_rol_fk
            WHERE i.pmg_status = 1;

        OPEN @CursorData;
        FETCH NEXT FROM @CursorData INTO @RoleName, @PermissionName;
        WHILE (@@FETCH_STATUS=0)
        BEGIN
            -- execute stored procedure for each iteration
            EXEC [dbo].[GrantRolePermission] @RoleName, @PermissionName;
            
            FETCH NEXT FROM @CursorData INTO @RoleName, @PermissionName;
        END
        CLOSE @CursorData;
        DEALLOCATE @CursorData;
    END
END
GO



/* Trigger fired on update action in the PermissionGranted table */
IF EXISTS(
    SELECT 1 FROM sys.tables tb 
        INNER JOIN sys.triggers tr ON tr.parent_id = tb.object_id
        INNER JOIN sys.schemas s ON tb.schema_id = s.schema_id
    WHERE tb.name = 'PermissionGranted' AND s.name = 'dbo'
    AND tr.type = 'TR' AND tr.name = 'trg_UPD_Permission'
    )
DROP TRIGGER [trg_UPD_Permission]
GO

CREATE TRIGGER [trg_UPD_Permission] ON [dbo].[PermissionGranted]
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @RoleName nvarchar(12),
            @PermissionName nvarchar(50),
            @PermissionStatus bit;
    DECLARE @CursorData CURSOR;
    
    -- process only those whose status has changed
    IF EXISTS(SELECT 1 FROM inserted i WHERE UPDATE(pmg_status))
    BEGIN
        -- a cursor has to be used to cater for multiple updates in one batch
        SET @CursorData = CURSOR FAST_FORWARD FOR
            SELECT r.rol_name, f.fnl_objectname
            FROM inserted i 
                INNER JOIN FunctionList f ON f.fnl_pk = pmg_fnl_fk
                INNER JOIN Roles r ON r.rol_pk = pmg_rol_fk
            WHERE UPDATE(pmg_status);

        OPEN @CursorData;
        FETCH NEXT FROM @CursorData INTO @RoleName, @PermissionName, @PermissionStatus;
        WHILE (@@FETCH_STATUS=0)
        BEGIN
            IF (@PermissionStatus = 1) -- Create New
                EXEC [dbo].[GrantRolePermission] @RoleName, @PermissionName;
            
            ELSE IF (@PermissionStatus = 0) -- Delete Existing
                EXEC [dbo].[RevokeRolePermission] @RoleName, @PermissionName;
                
            FETCH NEXT FROM @CursorData INTO @RoleName, @PermissionName, @PermissionStatus;
        END
        CLOSE @CursorData;
        DEALLOCATE @CursorData;
    END
END
GO
