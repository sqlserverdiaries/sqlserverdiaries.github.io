/* Create a sample database */
USE [master]
GO
CREATE DATABASE MyDatabase;
GO

EXEC MyDatabase..sp_changedbowner 'sa';
GO


/* Create the data store objects required for this example */
USE MyDatabase
GO

CREATE TABLE Users (
    usr_pk int IDENTITY(1,1) NOT NULL,
    usr_name nvarchar(12) NOT NULL,
    usr_status bit NOT NULL DEFAULT (1)
);

CREATE TABLE Roles (
    rol_pk int IDENTITY(1,1) NOT NULL,
    rol_name nvarchar(12) NOT NULL,
    rol_status bit NOT NULL DEFAULT (1)
);

CREATE TABLE RoleMembers (
    mem_pk int IDENTITY(1,1) NOT NULL,
    mem_usr_fk int NOT NULL,
    mem_rol_fk int NOT NULL,
    mem_status bit NOT NULL DEFAULT (1)
);
GO


/* Primary Key constraints */
ALTER TABLE Users 
    ADD CONSTRAINT PK_Users PRIMARY KEY CLUSTERED (usr_pk ASC)
ALTER TABLE Roles 
    ADD CONSTRAINT PK_Roles PRIMARY KEY CLUSTERED (rol_pk ASC)
ALTER TABLE RoleMembers 
    ADD CONSTRAINT PK_RoleMembers PRIMARY KEY CLUSTERED (mem_pk ASC)
GO


/* Foreign Key constraints */
ALTER TABLE RoleMembers WITH CHECK 
    ADD CONSTRAINT [FK_RoleMembers_User] FOREIGN KEY (mem_usr_fk) 
    REFERENCES Users (usr_pk) ON UPDATE NO ACTION ON DELETE NO ACTION 
ALTER TABLE RoleMembers WITH CHECK 
    ADD CONSTRAINT [FK_RoleMembers_Role] FOREIGN KEY (mem_rol_fk) 
    REFERENCES Roles (rol_pk) ON UPDATE NO ACTION ON DELETE NO ACTION 
GO


/* Unique Key constraints */
ALTER TABLE Users 
    ADD CONSTRAINT UNQ_Users_Name UNIQUE (usr_name)
ALTER TABLE Roles 
    ADD CONSTRAINT UNQ_Roles_Name UNIQUE (rol_name)
ALTER TABLE RoleMembers 
    ADD CONSTRAINT UNQ_RoleMembers_Link UNIQUE (mem_usr_fk, mem_rol_fk)
GO


/* Generate test data - see note in main article */
SET IDENTITY_INSERT Users ON;
INSERT INTO Users (usr_pk, usr_name, usr_status) VALUES (1, 'User001', 1);
INSERT INTO Users (usr_pk, usr_name, usr_status) VALUES (2, 'User002', 1);
INSERT INTO Users (usr_pk, usr_name, usr_status) VALUES (3, 'User003', 1);
INSERT INTO Users (usr_pk, usr_name, usr_status) VALUES (4, 'User004', 1);
SET IDENTITY_INSERT Users OFF;
GO

SET IDENTITY_INSERT Roles ON;
INSERT INTO Roles (rol_pk, rol_name, rol_status) VALUES (1, 'Role001', 1);
INSERT INTO Roles (rol_pk, rol_name, rol_status) VALUES (2, 'Role002', 1);
SET IDENTITY_INSERT Roles OFF;
GO

SET IDENTITY_INSERT RoleMembers ON;
INSERT INTO RoleMembers (mem_pk, mem_usr_fk, mem_rol_fk, mem_status) VALUES (1, 1, 1, 1);
INSERT INTO RoleMembers (mem_pk, mem_usr_fk, mem_rol_fk, mem_status) VALUES (2, 2, 1, 1);
INSERT INTO RoleMembers (mem_pk, mem_usr_fk, mem_rol_fk, mem_status) VALUES (3, 3, 2, 1);
INSERT INTO RoleMembers (mem_pk, mem_usr_fk, mem_rol_fk, mem_status) VALUES (4, 4, 2, 1);
INSERT INTO RoleMembers (mem_pk, mem_usr_fk, mem_rol_fk, mem_status) VALUES (5, 2, 2, 1);
SET IDENTITY_INSERT RoleMembers OFF;
GO


/* Set database property to allow escalation of privilege */
USE [master]
GO
ALTER DATABASE [MyDatabase] SET TRUSTWORTHY ON
GO


USE MyDatabase
GO

/* Procedure to generate a random password */
IF OBJECT_ID('dbo.GenerateRandomPassword') IS NOT NULL
    DROP PROCEDURE [dbo].[GenerateRandomPassword]
GO

CREATE PROCEDURE [dbo].[GenerateRandomPassword]
    @pwdLength TINYINT = 12,
    @IncludeLower TINYINT = 1,
    @IncludeUpper TINYINT = 1,
    @IncludeNumber TINYINT = 1,
    @IncludeSymbol TINYINT = 0,
    @randomPwd AS NVARCHAR(64) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    IF ((@IncludeLower + @IncludeUpper + @IncludeNumber + @IncludeSymbol) < 3) OR (@pwdLength < 8)
    BEGIN
        RAISERROR('Requested password will not meet complexity requirements.', 16, 1)
        RETURN -1;
    END;

    IF (@pwdLength > 64)
    BEGIN
        RAISERROR('Requested password will be too long.', 16, 1)
        RETURN -1;
    END

    DECLARE @idx AS INT;
    DECLARE @rnd AS FLOAT;
    DECLARE @char as NCHAR(1);

    SET @idx = 0;
    SET @char = N'';
    SET @rnd = RAND((@@CPU_BUSY % 100) + ((@@IDLE % 100) * 100) + (DATEPART(ss, CURRENT_TIMESTAMP) * 10000) + ((CAST(DATEPART(ms, CURRENT_TIMESTAMP) AS INT) % 100) * 1000000));
    
    WHILE (@idx < @pwdLength)
    BEGIN
        SET @char = CHAR((CAST((@rnd * 83) AS INT) + 43));
        IF ((@IncludeUpper = 1) AND (ASCII(@char) BETWEEN 65 AND 90)) OR                -- A-Z
           ((@IncludeLower = 1) AND (ASCII(@char) BETWEEN 97 AND 122)) OR               -- a-z
           ((@IncludeNumber = 1) AND (@char LIKE '[0-9]')) OR                           -- 0-9
           ((@IncludeSymbol = 1) AND (@char LIKE '[`!"�$%^&*()_+=- {};#:@~\|,./<>?]'))  -- symbols
        BEGIN
            SET @randomPwd = (@randomPwd + @char);
            SET @idx = @idx + 1;
        END
        SET @rnd = RAND();
    END
END
GO

/*
DECLARE @NewPwd NVARCHAR(64);
SET @NewPwd = '';
EXEC [dbo].[GenerateRandomPassword] @randomPwd = @NewPwd OUTPUT;
PRINT @NewPwd;
*/


/* Procedure to create a Login and Database User */
IF OBJECT_ID('dbo.CreateSQLUser') IS NOT NULL
    DROP PROCEDURE [dbo].[CreateSQLUser]
GO

CREATE PROCEDURE [dbo].[CreateSQLUser]
    @LoginName nvarchar(12)
WITH EXECUTE AS OWNER
AS
BEGIN
    DECLARE @SQLcmd nvarchar(2000);
    DECLARE @DatabaseName nvarchar(128);
    DECLARE @ErroMessage nvarchar(4000);

    SET @SQLcmd = '';
    SET @DatabaseName = DB_NAME();
    SET @ErroMessage = '';
    
    DECLARE @NewPwd NVARCHAR(64);
    SET @NewPwd = '';
    EXEC [dbo].[GenerateRandomPassword] @randomPwd = @NewPwd OUTPUT;

    BEGIN TRY
        SET @SQLcmd = N'
USE [master];
IF NOT EXISTS(SELECT 1 FROM sys.server_principals WHERE type_desc = ''SQL_LOGIN'' AND [name] = ''' + @LoginName + ''')
CREATE LOGIN ' + QUOTENAME(@LoginName, '[') + ' WITH PASSWORD=''' + @NewPwd + ''', CHECK_POLICY=ON, CHECK_EXPIRATION=OFF,DEFAULT_DATABASE=[' + @DatabaseName + '];'
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''SQL_USER'' AND [name] = ''' + @LoginName + ''')
CREATE USER ' + QUOTENAME(@LoginName, '[') + ' FOR LOGIN ' + QUOTENAME(@LoginName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''SQL_USER'' AND [name] = ''' + @LoginName + ''')
ALTER USER ' + QUOTENAME(@LoginName, '[') + ' WITH DEFAULT_SCHEMA=[dbo];';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
    END TRY
    BEGIN CATCH
        SET @ErroMessage = 'Error ' + CONVERT(varchar(50), ERROR_NUMBER()) +
            ', Severity ' + CONVERT(varchar(5), ERROR_SEVERITY()) +
            ', State ' + CONVERT(varchar(5), ERROR_STATE()) + 
            CHAR(10) + CHAR(13) + ERROR_MESSAGE();
        
        /* ***** ROLLBACK ABOVE ACTIONS ***** */
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF EXISTS(SELECT 1 FROM sys.schemas WHERE [name] = ''' + @LoginName + ''')
DROP SCHEMA ' + QUOTENAME(@LoginName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''SQL_USER'' AND [name] = ''' + @LoginName + ''')
DROP USER ' + QUOTENAME(@LoginName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        SET @SQLcmd = N'
USE [master];
IF EXISTS(SELECT 1 FROM sys.server_principals WHERE type_desc = ''SQL_LOGIN'' AND [name] = ''' + @LoginName + ''')
DROP LOGIN ' + QUOTENAME(@LoginName, '[') + ';'
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        RAISERROR(@ErroMessage, 16, 1);
    END CATCH
END
GO

/*
EXEC [dbo].[CreateSQLUser] 'User001';
*/


/* Procedure to create a Database Role */
IF OBJECT_ID('dbo.CreateRole') IS NOT NULL
    DROP PROCEDURE [dbo].[CreateRole]
GO

CREATE PROCEDURE [dbo].[CreateRole]
    @RoleName nvarchar(12)
WITH EXECUTE AS OWNER
AS
BEGIN
    DECLARE @SQLcmd nvarchar(2000);
    DECLARE @DatabaseName nvarchar(128);
    DECLARE @ErroMessage nvarchar(4000);

    SET @SQLcmd = '';
    SET @DatabaseName = DB_NAME();
    SET @ErroMessage = '';
    
    BEGIN TRY
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''DATABASE_ROLE'' AND [name] = ''' + @RoleName + ''')
CREATE ROLE ' + QUOTENAME(@RoleName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
    END TRY
    BEGIN CATCH
        SET @ErroMessage = 'Error ' + CONVERT(varchar(50), ERROR_NUMBER()) +
            ', Severity ' + CONVERT(varchar(5), ERROR_SEVERITY()) +
            ', State ' + CONVERT(varchar(5), ERROR_STATE()) + 
            CHAR(10) + CHAR(13) + ERROR_MESSAGE();
        
        /* ***** ROLLBACK ABOVE ACTIONS ***** */
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF EXISTS(SELECT 1 FROM sys.schemas WHERE [name] = ''' + @RoleName + ''')
DROP SCHEMA ' + QUOTENAME(@RoleName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''DATABASE_ROLE'' AND [name] = ''' + @RoleName + ''')
DROP ROLE ' + QUOTENAME(@RoleName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        RAISERROR(@ErroMessage, 16, 1);
    END CATCH
END
GO

/*
EXEC [dbo].[CreateRole] 'Role001';
*/


/* Procedure to link a Database User to a Database Role */
IF OBJECT_ID('dbo.AddUserToRole') IS NOT NULL
    DROP PROCEDURE [dbo].[AddUserToRole]
GO

CREATE PROCEDURE [dbo].[AddUserToRole]
    @LoginName nvarchar(12),
    @RoleName nvarchar(12)
WITH EXECUTE AS OWNER
AS
BEGIN
    DECLARE @SQLcmd nvarchar(2000);
    DECLARE @DatabaseName nvarchar(128);
    DECLARE @ErroMessage nvarchar(4000);

    SET @SQLcmd = '';
    SET @DatabaseName = DB_NAME();
    SET @ErroMessage = '';
    
    BEGIN TRY
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF (EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''DATABASE_ROLE'' AND [name] = ''' + @RoleName + ''') 
AND EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''SQL_USER'' AND [name] = ''' + @LoginName + '''))
    EXEC sys.sp_addrolemember ' + QUOTENAME(@RoleName, '[') + ', ' + QUOTENAME(@LoginName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
    END TRY
    BEGIN CATCH
        
        RAISERROR(@ErroMessage, 16, 1);
    END CATCH
END
GO

/*
EXEC [dbo].[AddUserToRole] 'User001', 'Role001';
*/


/* Procedure to delete a Database User and Login */
IF OBJECT_ID('dbo.DeleteSQLUser') IS NOT NULL
    DROP PROCEDURE [dbo].[DeleteSQLUser]
GO

CREATE PROCEDURE [dbo].[DeleteSQLUser]
    @LoginName nvarchar(12)
WITH EXECUTE AS OWNER
AS
BEGIN
    DECLARE @SQLcmd nvarchar(2000);
    DECLARE @DatabaseName nvarchar(128);
    DECLARE @ErroMessage nvarchar(4000);

    SET @SQLcmd = '';
    SET @DatabaseName = DB_NAME();
    SET @ErroMessage = '';
    
    BEGIN TRY
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF EXISTS(SELECT 1 FROM sys.schemas WHERE [name] = ''' + @LoginName + ''')
DROP SCHEMA ' + QUOTENAME(@LoginName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''SQL_USER'' AND [name] = ''' + @LoginName + ''')
DROP USER ' + QUOTENAME(@LoginName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
        SET @SQLcmd = N'
USE [master];
IF EXISTS(SELECT 1 FROM sys.server_principals WHERE type_desc = ''SQL_LOGIN'' AND [name] = ''' + @LoginName + ''')
DROP LOGIN ' + QUOTENAME(@LoginName, '[') + ';'
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
    END TRY
    BEGIN CATCH
        SET @ErroMessage = 'Error ' + CONVERT(varchar(50), ERROR_NUMBER()) +
            ', Severity ' + CONVERT(varchar(5), ERROR_SEVERITY()) +
            ', State ' + CONVERT(varchar(5), ERROR_STATE()) + 
            CHAR(10) + CHAR(13) + ERROR_MESSAGE();
        
        RAISERROR(@ErroMessage, 16, 1);
    END CATCH
END
GO

/*
EXEC [dbo].[DeleteSQLUser] 'User001';
*/


/* Procedure to remove a Database User from a Database Role */
IF OBJECT_ID('dbo.RemoveUserMembership') IS NOT NULL
    DROP PROCEDURE [dbo].[RemoveUserMembership]
GO

CREATE PROCEDURE [dbo].[RemoveUserMembership]
    @LoginName nvarchar(12),
    @RoleName nvarchar(12)
WITH EXECUTE AS OWNER
AS
BEGIN
    DECLARE @SQLcmd nvarchar(2000);
    DECLARE @DatabaseName nvarchar(128);
    DECLARE @ErroMessage nvarchar(4000);

    SET @SQLcmd = '';
    SET @DatabaseName = DB_NAME();
    SET @ErroMessage = '';
    
    BEGIN TRY
        SET @SQLcmd = N'
USE [' + @DatabaseName + '];
IF (EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''DATABASE_ROLE'' AND [name] = ''' + @RoleName + ''') 
AND EXISTS(SELECT 1 FROM sys.database_principals WHERE type_desc = ''SQL_USER'' AND [name] = ''' + @LoginName + '''))
    EXEC sys.sp_droprolemember ' + QUOTENAME(@RoleName, '[') + ', ' + QUOTENAME(@LoginName, '[') + ';';
        --PRINT @SQLcmd;
        EXEC sp_executesql @SQLcmd;
        
    END TRY
    BEGIN CATCH
        
        RAISERROR(@ErroMessage, 16, 1);
    END CATCH
END
GO

/*
EXEC [dbo].[RemoveUserMembership] 'User001', 'Role001';
*/


/* Trigger fired on insert action in the Users table */
IF EXISTS(
    SELECT 1 FROM sys.tables tb 
        INNER JOIN sys.triggers tr ON tr.parent_id = tb.object_id
        INNER JOIN sys.schemas s ON tb.schema_id = s.schema_id
    WHERE tb.name = 'Users' AND s.name = 'dbo'
    AND tr.type = 'TR' AND tr.name = 'trg_INS_User'
    )
DROP TRIGGER [trg_INS_User]
GO

CREATE TRIGGER [trg_INS_User] ON [dbo].[Users]
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @LoginName nvarchar(12);
    DECLARE @CursorData CURSOR;
    
    -- process only those which have been inserted with status = 1
    IF EXISTS (SELECT 1 FROM inserted i WHERE i.usr_status = 1)
    BEGIN
        -- a cursor has to be used to cater for multiple inserts in one batch (e.g. INSERT INTO...SELECT...)
        SET @CursorData = CURSOR FAST_FORWARD FOR
            SELECT i.usr_name FROM inserted i WHERE i.usr_status = 1;

        OPEN @CursorData;
        FETCH NEXT FROM @CursorData INTO @LoginName;
        WHILE (@@FETCH_STATUS=0)
        BEGIN
            -- execute stored procedure for each iteration
            EXEC [dbo].[CreateSQLUser] @LoginName;
            
            FETCH NEXT FROM @CursorData INTO @LoginName;
        END
        CLOSE @CursorData;
        DEALLOCATE @CursorData;
    END
END
GO


/* Trigger fired on update action in the Users table */
IF EXISTS(
    SELECT 1 FROM sys.tables tb 
        INNER JOIN sys.triggers tr ON tr.parent_id = tb.object_id
        INNER JOIN sys.schemas s ON tb.schema_id = s.schema_id
    WHERE tb.name = 'Users' AND s.name = 'dbo'
    AND tr.type = 'TR' AND tr.name = 'trg_UPD_User'
    )
DROP TRIGGER [trg_UPD_User]
GO

CREATE TRIGGER [trg_UPD_User] ON [dbo].[Users]
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @LoginName nvarchar(12),
            @LoginStatus bit;
    DECLARE @CursorData CURSOR;
    
    -- process only those whose status has changed
    IF EXISTS(SELECT 1 FROM inserted i WHERE UPDATE(usr_status))
    BEGIN
        -- a cursor has to be used to cater for multiple updates in one batch
        SET @CursorData = CURSOR FAST_FORWARD FOR
            SELECT i.usr_name, i.usr_status FROM inserted i WHERE UPDATE(usr_status);
        
        OPEN @CursorData;
        FETCH NEXT FROM @CursorData INTO @LoginName, @LoginStatus;
        WHILE (@@FETCH_STATUS=0)
        BEGIN
            IF (@LoginStatus = 1) -- Create New
                EXEC [dbo].[CreateSQLUser] @LoginName;
            
            ELSE IF (@LoginStatus = 0) -- Delete Existing
                EXEC [dbo].[DeleteSQLUser] @LoginName;
            
            FETCH NEXT FROM @CursorData INTO @LoginName, @LoginStatus;
        END
        CLOSE @CursorData;
        DEALLOCATE @CursorData;
    END
END
GO


/* Trigger fired on insert action in the Roles table */
IF EXISTS(
    SELECT 1 FROM sys.tables tb 
        INNER JOIN sys.triggers tr ON tr.parent_id = tb.object_id
        INNER JOIN sys.schemas s ON tb.schema_id = s.schema_id
    WHERE tb.name = 'Roles' AND s.name = 'dbo'
    AND tr.type = 'TR' AND tr.name = 'trg_INS_Role'
    )
DROP TRIGGER [trg_INS_Role]
GO

CREATE TRIGGER [trg_INS_Role] ON [dbo].[Roles]
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @RoleName nvarchar(12);
    DECLARE @CursorData CURSOR;
    
    -- process only those which have been inserted with status = 1
    IF EXISTS (SELECT 1 FROM inserted i WHERE i.rol_status = 1)
    BEGIN
        -- a cursor has to be used to cater for multiple inserts in one batch (e.g. INSERT INTO...SELECT...)
        SET @CursorData = CURSOR FAST_FORWARD FOR
            SELECT i.rol_name FROM inserted i WHERE i.rol_status = 1;

        OPEN @CursorData;
        FETCH NEXT FROM @CursorData INTO @RoleName;
        WHILE (@@FETCH_STATUS=0)
        BEGIN
            -- execute stored procedure for each iteration
            EXEC [dbo].[CreateRole] @RoleName;
            
            FETCH NEXT FROM @CursorData INTO @RoleName;
        END
        CLOSE @CursorData;
        DEALLOCATE @CursorData;
    END
END
GO


/* Trigger fired on insert action in the RoleMembers table */
IF EXISTS(
    SELECT 1 FROM sys.tables tb 
        INNER JOIN sys.triggers tr ON tr.parent_id = tb.object_id
        INNER JOIN sys.schemas s ON tb.schema_id = s.schema_id
    WHERE tb.name = 'RoleMembers' AND s.name = 'dbo'
    AND tr.type = 'TR' AND tr.name = 'trg_INS_RoleMembers'
    )
DROP TRIGGER [trg_INS_RoleMembers]
GO

CREATE TRIGGER [trg_INS_RoleMembers] ON [dbo].[RoleMembers]
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @LoginName nvarchar(12),
            @RoleName nvarchar(12);
    DECLARE @CursorData CURSOR;
    
    -- process only those which have been inserted with status = 1
    IF EXISTS (SELECT 1 FROM inserted i WHERE i.mem_status = 1)
    BEGIN
        -- a cursor has to be used to cater for multiple inserts in one batch (e.g. INSERT INTO...SELECT...)
        SET @CursorData = CURSOR FAST_FORWARD FOR
            SELECT u.usr_name, r.rol_name
            FROM inserted i 
                INNER JOIN Users u ON i.mem_usr_fk = u.usr_pk
                INNER JOIN Roles r ON i.mem_rol_fk = r.rol_pk
            WHERE i.mem_status = 1;

        OPEN @CursorData;
        FETCH NEXT FROM @CursorData INTO @LoginName, @RoleName;
        WHILE (@@FETCH_STATUS=0)
        BEGIN
            -- execute stored procedure for each iteration
            EXEC [dbo].[AddUserToRole] @LoginName, @RoleName;
            
            FETCH NEXT FROM @CursorData INTO @LoginName, @RoleName;
        END
        CLOSE @CursorData;
        DEALLOCATE @CursorData;
    END
END
GO


/* Trigger fired on update action in the RoleMembers table */
IF EXISTS(
    SELECT 1 FROM sys.tables tb 
        INNER JOIN sys.triggers tr ON tr.parent_id = tb.object_id
        INNER JOIN sys.schemas s ON tb.schema_id = s.schema_id
    WHERE tb.name = 'RoleMembers' AND s.name = 'dbo'
    AND tr.type = 'TR' AND tr.name = 'trg_UPD_RoleMembers'
    )
DROP TRIGGER [trg_UPD_RoleMembers]
GO

CREATE TRIGGER [trg_UPD_RoleMembers] ON [dbo].[RoleMembers]
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @LoginName nvarchar(12),
            @RoleName nvarchar(12),
            @MembershipStatus bit;
    DECLARE @CursorData CURSOR;
    
    -- process only those whose status has changed
    IF EXISTS (SELECT 1 FROM inserted i WHERE UPDATE(mem_status))
    BEGIN
        -- a cursor has to be used to cater for multiple updates in one batch
        SET @CursorData = CURSOR FAST_FORWARD FOR
            SELECT u.usr_name, r.rol_name, i.mem_status
            FROM inserted i 
                INNER JOIN Users u ON i.mem_usr_fk = u.usr_pk
                INNER JOIN Roles r ON i.mem_rol_fk = r.rol_pk
            WHERE UPDATE(mem_status);
        
        OPEN @CursorData;
        FETCH NEXT FROM @CursorData INTO @LoginName, @RoleName, @MembershipStatus;
        WHILE (@@FETCH_STATUS=0)
        BEGIN
            IF (@MembershipStatus = 1) -- Create New
                EXEC [dbo].[AddUserToRole] @LoginName, @RoleName;
            
            ELSE IF (@MembershipStatus = 0) -- Delete Existing
                EXEC [dbo].[RemoveUserMembership] @LoginName, @RoleName;
            
            FETCH NEXT FROM @CursorData INTO @LoginName, @RoleName, @MembershipStatus;
        END
        CLOSE @CursorData;
        DEALLOCATE @CursorData;
    END
END
GO


/* Some more testing... */
-- delete membership for User001
UPDATE RoleMembers SET mem_status = 0 WHERE mem_usr_fk = 1;
GO

-- delete user and login for User003
UPDATE Users SET usr_status = 0 WHERE usr_pk = 3;
GO


/* Clean Up - make sure you remove any orphaned Logins after executing the below */
USE [master]
GO
DROP DATABASE MyDatabase;
GO
