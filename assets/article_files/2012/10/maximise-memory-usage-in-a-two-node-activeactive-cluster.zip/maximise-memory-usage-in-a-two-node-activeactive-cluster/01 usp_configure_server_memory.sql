USE [master]
GO

CREATE PROCEDURE dbo.usp_configure_server_memory
    @CallingNodeHostName nvarchar(128),
    @FullMemoryAllocation int,
    @CurrentNodeHostName nvarchar(128) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @MemoryAllocation int;
    DECLARE @ShowAdvancedOptionChanged bit;
    
    SET @ShowAdvancedOptionChanged = 0;
    SET @CurrentNodeHostName = CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as nvarchar(128));
    
    -- retrieve current host name
    IF (@CurrentNodeHostName = @CallingNodeHostName)
    BEGIN
        -- if calling SQL Server instance is hosted on the CURRENT host, run in "degraded mode"
        SET @MemoryAllocation = FLOOR(@FullMemoryAllocation/2);
    END
    ELSE
    BEGIN
        -- if calling SQL Server instance is hosted on the REMOTE host, run in "degraded mode"
        SET @MemoryAllocation = FLOOR(@FullMemoryAllocation);
    END
    
    -- reconfigure memory allocation
    -- check current value
    IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE [name] = 'max server memory (MB)' AND [value] = @MemoryAllocation)
    BEGIN
        -- enable "show advanced options" option
        IF NOT EXISTS(SELECT 1 FROM sys.configurations WHERE [name] = 'show advanced options' AND [value] = 1)
        BEGIN
            EXEC sp_configure 'show advanced options', 1;
            RECONFIGURE WITH OVERRIDE;
            SET @ShowAdvancedOptionChanged = 1;
        END
        
        -- reconfigure memory
        EXEC sp_configure 'max server memory (MB)', @MemoryAllocation;
        RECONFIGURE WITH OVERRIDE;
        
        -- disable "show advanced options" option
        IF ((@ShowAdvancedOptionChanged = 1) AND 
            (NOT EXISTS(SELECT 1 FROM sys.configurations WHERE [name] = 'show advanced options' AND [value] = 0)))
        BEGIN
            EXEC sp_configure 'show advanced options', 0;
            RECONFIGURE WITH OVERRIDE;
        END
    END
END
GO
