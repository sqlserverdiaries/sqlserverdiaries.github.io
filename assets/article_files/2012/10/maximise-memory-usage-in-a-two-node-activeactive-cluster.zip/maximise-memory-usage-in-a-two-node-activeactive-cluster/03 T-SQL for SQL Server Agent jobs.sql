

-- On: SQLSRV2\SQLINST2
SET NOCOUNT ON;
DECLARE @CurrentHostName nvarchar(128),
        @RemoteHostName nvarchar(128);

SET @CurrentHostName = CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as nvarchar(128));
SET @RemoteHostName = '';

PRINT @CurrentHostName;

PRINT 'SQLSRV1\SQLINST1';
EXEC [SQLSRV1\SQLINST1].master.dbo.usp_configure_server_memory
    @CallingNodeHostName = @CurrentHostName,
    @FullMemoryAllocation = 1024,
    @CurrentNodeHostName = @RemoteHostName OUTPUT;

PRINT 'SQLSRV2\SQLINST2';
EXEC master.dbo.usp_configure_server_memory
    @CallingNodeHostName = @RemoteHostName,
    @FullMemoryAllocation = 1024,
    @CurrentNodeHostName = '';




-- On: SQLSRV1\SQLINST1
SET NOCOUNT ON;
DECLARE @CurrentHostName nvarchar(128),
        @RemoteHostName nvarchar(128);

SET @CurrentHostName = CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as nvarchar(128));
SET @RemoteHostName = '';

PRINT @CurrentHostName;

PRINT 'SQLSRV2\SQLINST2';
EXEC [SQLSRV2\SQLINST2].master.dbo.usp_configure_server_memory
    @CallingNodeHostName = @CurrentHostName,
    @FullMemoryAllocation = 1024,
    @CurrentNodeHostName = @RemoteHostName OUTPUT;

PRINT 'SQLSRV1\SQLINST1';
EXEC master.dbo.usp_configure_server_memory
    @CallingNodeHostName = @RemoteHostName,
    @FullMemoryAllocation = 1024,
    @CurrentNodeHostName = '';
