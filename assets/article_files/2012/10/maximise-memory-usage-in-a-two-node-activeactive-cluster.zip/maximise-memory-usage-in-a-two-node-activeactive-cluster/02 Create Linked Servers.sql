
-- On: SQLSRV1\SQLINST1
EXEC master.dbo.sp_addlinkedserver 
    @server = N'SQLSRV2\SQLINST2', 
    @srvproduct=N'SQLSRV2\SQLINST2', 
    @provider=N'SQLNCLI', 
    @datasrc=N'SQLSRV2\SQLINST2', 
    @catalog=N'master';

EXEC master.dbo.sp_addlinkedsrvlogin 
    @rmtsrvname=N'SQLSRV2\SQLINST2',
    @useself=N'True',
    @locallogin=NULL,
    @rmtuser=NULL,
    @rmtpassword=NULL;

EXEC master.dbo.sp_serveroption 
    @server=N'SQLSRV2\SQLINST2', 
    @optname=N'rpc out', 
    @optvalue=N'true';



-- On: SQLSRV2\SQLINST2
EXEC master.dbo.sp_addlinkedserver 
    @server = N'SQLSRV1\SQLINST1', 
    @srvproduct=N'SQLSRV1\SQLINST1', 
    @provider=N'SQLNCLI', 
    @datasrc=N'SQLSRV1\SQLINST1', 
    @catalog=N'master';

EXEC master.dbo.sp_addlinkedsrvlogin 
    @rmtsrvname=N'SQLSRV1\SQLINST1',
    @useself=N'True',
    @locallogin=NULL,
    @rmtuser=NULL,
    @rmtpassword=NULL;

EXEC master.dbo.sp_serveroption 
    @server=N'SQLSRV1\SQLINST1', 
    @optname=N'rpc out', 
    @optvalue=N'true';
