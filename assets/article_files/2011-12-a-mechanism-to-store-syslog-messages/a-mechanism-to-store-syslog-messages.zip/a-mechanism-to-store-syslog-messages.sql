USE [master]
GO

CREATE DATABASE [db_syslog] ON 
 PRIMARY ( 
    NAME = N'db_syslog', 
    FILENAME = N'D:\MSSQL\DATA\db_syslog.mdf' , 
    SIZE = 10MB , 
    MAXSIZE = UNLIMITED, 
    FILEGROWTH = 10MB ), 
 FILEGROUP [TABLES] DEFAULT ( 
    NAME = N'db_syslog_tables_1', 
    FILENAME = N'D:\MSSQL\DATA\db_syslog_tables_1.ndf' , 
    SIZE = 125GB , 
    MAXSIZE = 125GB , 
    FILEGROWTH = 10MB ), 
  ( NAME = N'db_syslog_tables_2', 
    FILENAME = N'D:\MSSQL\DATA\db_syslog_tables_2.ndf' , 
    SIZE = 125GB , 
    MAXSIZE = 125GB , 
    FILEGROWTH = 10MB ),
  ( NAME = N'db_syslog_tables_3', 
    FILENAME = N'D:\MSSQL\DATA\db_syslog_tables_3.ndf' , 
    SIZE = 125GB , 
    MAXSIZE = 125GB , 
    FILEGROWTH = 10MB ),
  ( NAME = N'db_syslog_tables_4', 
    FILENAME = N'D:\MSSQL\DATA\db_syslog_tables_4.ndf' , 
    SIZE = 125GB , 
    MAXSIZE = 125GB , 
    FILEGROWTH = 10MB )
 LOG ON ( 
    NAME = N'db_syslog_log', 
    FILENAME = N'D:\MSSQL\DATA\db_syslog_log.ldf' , 
    SIZE = 100MB , 
    MAXSIZE = 5GB , 
    FILEGROWTH = 10MB )
GO

ALTER DATABASE [db_syslog] SET COMPATIBILITY_LEVEL = 100
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
    EXEC [db_syslog].[dbo].[sp_fulltext_database] @action = 'enable'
GO

ALTER DATABASE [db_syslog] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [db_syslog] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [db_syslog] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [db_syslog] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [db_syslog] SET ARITHABORT OFF 
GO

ALTER DATABASE [db_syslog] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [db_syslog] SET AUTO_CREATE_STATISTICS ON 
GO

ALTER DATABASE [db_syslog] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [db_syslog] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [db_syslog] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [db_syslog] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [db_syslog] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [db_syslog] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [db_syslog] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [db_syslog] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [db_syslog] SET DISABLE_BROKER 
GO

ALTER DATABASE [db_syslog] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [db_syslog] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [db_syslog] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [db_syslog] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [db_syslog] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [db_syslog] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [db_syslog] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [db_syslog] SET READ_WRITE 
GO

ALTER DATABASE [db_syslog] SET RECOVERY BULK_LOGGED 
GO

ALTER DATABASE [db_syslog] SET MULTI_USER 
GO

ALTER DATABASE [db_syslog] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [db_syslog] SET DB_CHAINING OFF 
GO

USE [db_syslog]
GO

IF NOT EXISTS (SELECT name FROM sys.filegroups WHERE is_default=1 AND name = N'TABLES') 
    ALTER DATABASE [db_syslog] MODIFY FILEGROUP [TABLES] DEFAULT
GO

EXEC sp_changedbowner 'sa'
GO



USE [db_syslog]
GO

CREATE SCHEMA [syslog]
GO

/*
NOTE:
    Set the minimum value of IDENTITY property to minimum of INT data type to avoid using a BIGINT data type.  With a 
    difference of 4 bytes between an INT and BIGINT data type, the difference in storage space required for 2.1 billion 
    records would be around 8GB per table.
    
    The MsgDate data type was modified from the original schema from a datetime to a datetime2(0).  The difference between the two is 2 bytes per row which on 2.1 billion records amounts to almost 4GB per table.
    
*/
CREATE TABLE [syslog].tb_syslogd_01 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_02 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_03 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_04 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_05 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_06 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_07 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_08 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_09 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_10 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_11 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].tb_syslogd_12 (
    MsgPK int IDENTITY(-2147483648,1) NOT NULL,
    MsgDate datetime2(0),
    MsgPriority VARCHAR(30),
    MsgHostname VARCHAR(255),
    MsgText VARCHAR(max)
) ON [TABLES];
GO

CREATE TABLE [syslog].[tb_params](
	[param_pk] [smallint] IDENTITY(1,1) NOT NULL,
	[param_desc] [nvarchar](25) NOT NULL,
	[param_value] [nvarchar](255) NULL,
	[param_status] [nchar](1) NULL
) ON [TABLES]
GO

ALTER TABLE [syslog].[tb_params] ADD DEFAULT ('A') FOR [param_status]
GO


CREATE VIEW dbo.tb_syslogd
AS
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_01 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_02 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_03 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_04 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_05 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_06 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_07 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_08 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_09 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_10 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_11 UNION ALL
SELECT MsgDate, MsgPriority, MsgHostname, MsgText FROM [syslog].tb_syslogd_12
GO


USE [db_syslog]
GO

-- create default param values
SET IDENTITY_INSERT syslog.tb_params ON;
INSERT INTO syslog.tb_params (param_pk, param_desc, param_value, param_status)
    VALUES(1, 'BULK_LOAD_FILE_PATH', 'D:\syslogs\capture.txt.001', 'A');
INSERT INTO syslog.tb_params (param_pk, param_desc, param_value, param_status)
    VALUES(2, 'BULK_LOAD_CONFIG_PATH', 'D:\syslogs\capture.fmt', 'A');
INSERT INTO syslog.tb_params (param_pk, param_desc, param_value, param_status)
    VALUES(3, 'DATA_HOARD_MONTHS', '2', 'A');
SET IDENTITY_INSERT syslog.tb_params OFF;
GO



/* ***** FORMAT FILE ***** */
/*
10.0
4
1       SQLCHAR             0       24      "\t"     2     MsgDate                    ""
2       SQLCHAR             0       30      "\t"     3     MsgPriority                SQL_Latin1_General_CP1_CI_AS
3       SQLCHAR             0       255     "\t"     4     MsgHostname                SQL_Latin1_General_CP1_CI_AS
4       SQLCHAR             0       0       "\r\n"   5     MsgText                    SQL_Latin1_General_CP1_CI_AS
*/



USE [db_syslog]
GO

CREATE PROCEDURE [syslog].[usp_bulkloadfile]
AS
SET NOCOUNT ON;
DECLARE @filepath nvarchar(256) = (SELECT [param_value] FROM [syslog].[tb_params] WHERE [param_desc] = 'BULK_LOAD_FILE_PATH');
DECLARE @configpath nvarchar(256) = (SELECT [param_value] FROM [syslog].[tb_params] WHERE [param_desc] = 'BULK_LOAD_CONFIG_PATH');
DECLARE @UploadMonth smallint = (SELECT DATEPART(m, DATEADD(hh, -1, CURRENT_TIMESTAMP)));
DECLARE @SQL nvarchar(2000) = N'';

-- execute the bulk load statement
-- file name is hard-coded since this is set in the application
SET @SQL = '
SET NOCOUNT ON;
BULK INSERT [db_syslog].[syslog].[tb_syslogd_' + RIGHT('0' + CAST(@UploadMonth AS nvarchar(2)), 2) + '] FROM ''' + @filepath + '''
WITH ( 
    FIELDTERMINATOR = ''\t'',
    FIRSTROW = 1,
    DATAFILETYPE = ''char'',
    FORMATFILE = ''' + @configpath + ''',
    KEEPNULLS,
    MAXERRORS = 1,
    ROWTERMINATOR = ''\n'',
    ORDER (MsgDate ASC),
    TABLOCK
);
PRINT CONVERT(varchar(25), CURRENT_TIMESTAMP, 121) + '' - '' + CAST(@@ROWCOUNT AS varchar(20)) + '' rows loaded to table tb_syslogd_' + RIGHT('0' + CAST(@UploadMonth AS nvarchar(2)), 2) + ''';';
--PRINT @SQL;
SET NOCOUNT OFF;
EXEC sp_executesql @SQL;
GO


USE [db_syslog]
GO

CREATE PROCEDURE [syslog].[usp_purgeoldrecords]
AS
SET NOCOUNT ON
DECLARE @MaxRetentionMonths int = 0 - (
    SELECT TOP(1) CONVERT(int, [param_value]) FROM syslog.tb_params WHERE [param_desc]='DATA_HOARD_MONTHS' AND [param_status]='A');
DECLARE @MaxRetentionDate datetime = DATEADD(m, @MaxRetentionMonths, CURRENT_TIMESTAMP);
DECLARE @ClearMonth smallint = (SELECT DATEPART(m, @MaxRetentionDate))
BEGIN
    PRINT 'Deleting data for ' + DATENAME(m, @MaxRetentionDate);
    IF (@ClearMonth = 1)      -- January
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_01;
        DBCC CHECKIDENT ('syslog.tb_syslogd_01', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 2) -- February
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_02;
        DBCC CHECKIDENT ('syslog.tb_syslogd_02', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 3) -- March
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_03;
        DBCC CHECKIDENT ('syslog.tb_syslogd_03', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 4) -- April
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_04;
        DBCC CHECKIDENT ('syslog.tb_syslogd_04', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 5) -- May
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_05;
        DBCC CHECKIDENT ('syslog.tb_syslogd_05', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 6) -- June
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_06;
        DBCC CHECKIDENT ('syslog.tb_syslogd_06', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 7) -- July
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_07;
        DBCC CHECKIDENT ('syslog.tb_syslogd_07', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 8) -- August
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_08;
        DBCC CHECKIDENT ('syslog.tb_syslogd_08', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 9) -- September
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_09;
        DBCC CHECKIDENT ('syslog.tb_syslogd_09', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 10) -- October
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_10;
        DBCC CHECKIDENT ('syslog.tb_syslogd_10', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 11) -- November
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_11;
        DBCC CHECKIDENT ('syslog.tb_syslogd_11', RESEED, -2147483648);
    END
    ELSE IF (@ClearMonth = 12) -- December
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_12;
        DBCC CHECKIDENT ('syslog.tb_syslogd_12', RESEED, -2147483648);
    END
    ELSE                       -- Anything else (invalid data?)
    BEGIN
        TRUNCATE TABLE [syslog].tb_syslogd_00;
        DBCC CHECKIDENT ('syslog.tb_syslogd_00', RESEED, -2147483648);
    END
END
GO
