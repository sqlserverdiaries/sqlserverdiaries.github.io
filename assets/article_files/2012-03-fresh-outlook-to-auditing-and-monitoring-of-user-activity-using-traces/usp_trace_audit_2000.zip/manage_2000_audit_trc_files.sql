SET NOCOUNT ON;

CREATE TABLE #dirfiles (
    [FileNameID] int identity (1,1),
    [FileName] nvarchar (128)
);

CREATE TABLE #delcommands (
    doscommand nvarchar(2000) NOT NULL
);

DECLARE @filepath nvarchar(128);
DECLARE @cmd nvarchar(2000);
DECLARE @deletedfiles int;

SET @filepath = 'D:\MSSQL\AUDIT\';
SET @cmd = 'dir ' + @filepath + '*.trc /b /OD';
SET @deletedfiles = 0;

INSERT INTO #dirfiles (FileName)
	EXEC xp_cmdshell @cmd;

INSERT INTO #delcommands
    SELECT 'del "' + @filepath + [FileName] + '" /q'
    FROM #dirfiles 
    WHERE [FileName] IS NOT NULL
	AND [FileName] NOT IN (
		SELECT TOP 400 [FileName] 
		FROM #dirfiles
		WHERE [FileName] IS NOT NULL
		ORDER BY [FileNameID] DESC
		);

IF EXISTS (SELECT 1 FROM #delcommands)
BEGIN
    SET @cmd = '';
    DECLARE curFileList CURSOR FOR
	    SELECT doscommand FROM #delcommands;
    
    OPEN curFileList;
    FETCH NEXT FROM curFileList INTO @cmd;
    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        PRINT @cmd;
	    EXEC xp_cmdshell @cmd, NO_OUTPUT;
    	
	    FETCH NEXT FROM curFileList INTO @cmd;	
    END
    CLOSE curFileList;
    DEALLOCATE curFileList;
    
    SET @deletedfiles = (SELECT COUNT(*) FROM #delcommands);
    PRINT CONVERT(varchar(20), CURRENT_TIMESTAMP, 120) + ' - ' + CAST(@deletedfiles as varchar(10)) + ' files deleted.';
END
ELSE
BEGIN
    PRINT CONVERT(varchar(20), CURRENT_TIMESTAMP, 120) + ' - No files to delete.';
END

DROP TABLE #dirfiles;
DROP TABLE #delcommands;
