SET NOCOUNT ON;

SELECT 'USE ' + QUOTENAME(DB_NAME(), '[') + '
GO';

WITH cteDBSchema 
AS (
SELECT extern.TABLE_SCHEMA, extern.TABLE_NAME,
       LEFT(column_definitions, LEN(column_definitions) - 1) AS column_definitions
FROM INFORMATION_SCHEMA.COLUMNS AS extern
    INNER JOIN INFORMATION_SCHEMA.TABLES tbl ON tbl.TABLE_SCHEMA = extern.TABLE_SCHEMA AND tbl.TABLE_NAME = extern.TABLE_NAME
    CROSS APPLY ( SELECT '{RETURN}    ' + QUOTENAME(COLUMN_NAME, '[') + ' ' +
                    QUOTENAME(DATA_TYPE, '[') + 
                    CASE DATA_TYPE
                        WHEN 'char' THEN (CASE ISNULL(CHARACTER_MAXIMUM_LENGTH, 0) WHEN 0 THEN '' WHEN -1 THEN '(MAX)' ELSE '(' + convert(varchar(10), CHARACTER_MAXIMUM_LENGTH) + ')' END)
                        WHEN 'nchar' THEN (CASE ISNULL(CHARACTER_MAXIMUM_LENGTH, 0) WHEN 0 THEN '' WHEN -1 THEN '(MAX)' ELSE '(' + convert(varchar(10), CHARACTER_MAXIMUM_LENGTH) + ')' END)
                        WHEN 'varchar' THEN (CASE ISNULL(CHARACTER_MAXIMUM_LENGTH, 0) WHEN 0 THEN '' WHEN -1 THEN '(MAX)' ELSE '(' + convert(varchar(10), CHARACTER_MAXIMUM_LENGTH) + ')' END)
                        WHEN 'nvarchar' THEN (CASE ISNULL(CHARACTER_MAXIMUM_LENGTH, 0) WHEN 0 THEN '' WHEN -1 THEN '(MAX)' ELSE '(' + convert(varchar(10), CHARACTER_MAXIMUM_LENGTH) + ')' END)
                        WHEN 'numeric' THEN (CASE ISNULL(NUMERIC_PRECISION, 0) WHEN 0 THEN '' ELSE '(' + convert(varchar(10), NUMERIC_PRECISION) + ', ' + convert(varchar(10), NUMERIC_SCALE) + ')' END)
                        WHEN 'decimal' THEN (CASE ISNULL(NUMERIC_PRECISION, 0) WHEN 0 THEN '' ELSE '(' + convert(varchar(10), NUMERIC_PRECISION) + ', ' + convert(varchar(10), NUMERIC_SCALE) + ')' END)
                        WHEN 'varbinary' THEN (CASE CHARACTER_MAXIMUM_LENGTH WHEN -1 THEN '(max)' ELSE '(' + convert(varchar(10), CHARACTER_MAXIMUM_LENGTH) + ')' END)
                        ELSE ''
                    END + 
                    CASE WHEN DATA_TYPE LIKE '%char' THEN ' COLLATE ' + COLLATION_NAME
                        ELSE ''
                    END + 
                    -- script IDENTITY property
                    ISNULL((
                        SELECT ' IDENTITY (' + CAST(sic.[seed_value] AS varchar(10)) + ',' + CAST(sic.[increment_value] AS varchar(10)) + ')'
                        FROM sys.identity_columns sic
                        WHERE sic.[object_id] = OBJECT_ID(intern.TABLE_SCHEMA + '.' + intern.TABLE_NAME)
                        AND sic.[name] = intern.COLUMN_NAME
                    ), '') +
                    
                    CASE IS_NULLABLE WHEN 'NO' THEN ' NOT' ELSE '' END + ' NULL' + ','
                FROM INFORMATION_SCHEMA.COLUMNS AS intern
                WHERE  extern.TABLE_NAME = intern.TABLE_NAME
                AND    extern.TABLE_SCHEMA = intern.TABLE_SCHEMA
                ORDER BY intern.ORDINAL_POSITION
                FOR XML PATH('')
                ) pre_trimmed (column_definitions)
WHERE extern.TABLE_NAME NOT IN ('dtproperties', 'sysconstraints', 'syssegments')
AND tbl.TABLE_TYPE = 'BASE TABLE'
GROUP BY extern.TABLE_SCHEMA, extern.TABLE_NAME, pre_trimmed.column_definitions
)
SELECT 'CREATE TABLE ' + QUOTENAME(TABLE_SCHEMA, '[') + '.' + QUOTENAME(TABLE_NAME, '[') + 
' (' + REPLACE(column_definitions, '{RETURN}', CHAR(13)) + '
) ON ' + QUOTENAME(ds.name) + ';' + CHAR(13)
FROM sys.indexes ix
    INNER JOIN sys.data_spaces ds ON ds.data_space_id = ix.data_space_id
    INNER JOIN cteDBSchema t ON OBJECT_ID(t.TABLE_SCHEMA + '.' + t.TABLE_NAME) = ix.object_id
WHERE ix.object_id > 100 AND ix.type <=1
ORDER BY ds.name, TABLE_SCHEMA, TABLE_NAME;
