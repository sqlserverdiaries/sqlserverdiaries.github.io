SET NOCOUNT ON;

CREATE TABLE tempdb..ExcludeDatabases(
    database_name nvarchar(128) NOT NULL
    );
    
-- Exclude all system databases
INSERT INTO tempdb..ExcludeDatabases (database_name)
    SELECT 'master' UNION ALL
    SELECT 'model' UNION ALL
    SELECT 'msdb' UNION ALL
    SELECT 'tempdb';

-- Exclude all sample databases
INSERT INTO tempdb..ExcludeDatabases (database_name)
    SELECT 'AdventureWorks' UNION ALL
    SELECT 'AdventureWorksDW' UNION ALL
    SELECT 'AdventureWorksLT' UNION ALL
    SELECT 'georgetown' UNION ALL
    SELECT 'Northwind' UNION ALL
    SELECT 'pubs';

SELECT  TOP 100 PERCENT [name] FROM master..sysdatabases
WHERE   [name] NOT IN (SELECT database_name FROM tempdb..ExcludeDatabases)
AND     [name] NOT LIKE 'ReportServer$%' -- Exclude SQL Server Reporting Services databases
AND     ISNULL(DATABASEPROPERTY([name], 'IsReadOnly'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsOffline'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsSuspect'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsShutDown'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsNotRecovered'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsInStandBy'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsInRecovery'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsInLoad'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsEmergencyMode'), 0) = 0
AND     ISNULL(DATABASEPROPERTY([name], 'IsDetached'), 0) = 0 
ORDER BY [name] ASC;

DROP TABLE tempdb..ExcludeDatabases;
